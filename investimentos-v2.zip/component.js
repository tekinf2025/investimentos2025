// <stdin>
import React, { useState, useEffect } from "https://esm.sh/react@18.2.0";
import { PlusCircle, TrendingUp, TrendingDown, DollarSign, Calendar, Hash, Tag, Info, BarChart3, User, Settings, PieChart, Gift, Home, Receipt, Filter, Target, Activity, Edit3, Trash2, X, Save, Download, Upload, FileDown, FileUp, Shield, AlertTriangle, CheckCircle, XCircle } from "https://esm.sh/lucide-react?deps=react@18.2.0,react-dom@18.2.0";
import { createClient } from "https://esm.sh/https://cdn.skypack.dev/@supabase/supabase-js?deps=react@18.2.0,react-dom@18.2.0";
var supabaseUrl = "https://empucpjeocyhqdnlzghy.supabase.co";
var supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVtcHVjcGplb2N5aHFkbmx6Z2h5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMxOTc1NzMsImV4cCI6MjA2ODc3MzU3M30.MI9Mb6RdaGUuBrwmkzuWWiGtCtCbQxTcPoGf_uPLJXM";
var supabase = createClient(supabaseUrl, supabaseAnonKey);
var { useStoredState } = hatch;
var InvestmentManager = () => {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [compras, setCompras] = useState([]);
  const [vendas, setVendas] = useState([]);
  const [proventos, setProventos] = useState([]);
  const [derivativos, setDerivativos] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState("connecting");
  const [formData, setFormData] = useState({
    tipo_ativo: "",
    ativo: "",
    data: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    quantidade: "",
    preco: "",
    outros_custos: ""
  });
  const [proventoData, setProventoData] = useState({
    tipo_provento: "",
    ativo: "",
    data: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    valor: "",
    quantidade: "",
    a_receber: false
  });
  const [derivativoData, setDerivativoData] = useState({
    tipo_operacao: "",
    tipo_derivativo: "",
    ativo_subjacente: "",
    codigo_opcao: "",
    strike: "",
    data: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    quantidade: "",
    preco: "",
    outros_custos: "",
    status: "aberta"
  });
  const [filters, setFilters] = useState({
    tipo_provento: "",
    ativo: "",
    ano: (/* @__PURE__ */ new Date()).getFullYear()
  });
  const [errors, setErrors] = useState({});
  const [proventoErrors, setProventoErrors] = useState({});
  const [derivativoErrors, setDerivativoErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editingProventoId, setEditingProventoId] = useState(null);
  const [editingDerivativoId, setEditingDerivativoId] = useState(null);
  const [carteiraFilters, setCarteiraFilters] = useState({
    tipo_ativo: "",
    periodo: "",
    busca: ""
  });
  const [sortConfig, setSortConfig] = useState({
    key: null,
    direction: "asc"
  });
  const [valoresAtuais, setValoresAtuais] = useStoredState("investment_valores_atuais", {});
  const [editingValorAtivo, setEditingValorAtivo] = useState(null);
  const [valorAtualTemp, setValorAtualTemp] = useState("");
  const [isUpdatingPrices, setIsUpdatingPrices] = useState(false);
  const [lastUpdateTime, setLastUpdateTime] = useStoredState("investment_last_update", null);
  const [priceUpdateMessage, setPriceUpdateMessage] = useState("");
  const [updatingSingleStock, setUpdatingSingleStock] = useState(null);
  const [autoUpdateEnabled, setAutoUpdateEnabled] = useStoredState("investment_auto_update", false);
  const tiposAtivos = [
    { value: "acoes", label: "A\xE7\xF5es" },
    { value: "fundos_imobiliarios", label: "Fundos Imobili\xE1rios" },
    { value: "criptomoedas", label: "Criptomoedas" },
    { value: "fundos_investimento", label: "Fundos de Investimento" },
    { value: "renda_fixa", label: "Renda Fixa" },
    { value: "etfs", label: "ETFs" }
  ];
  const tiposProventos = [
    { value: "dividendos", label: "Dividendos" },
    { value: "jcp", label: "Juros sobre Capital Pr\xF3prio (JCP)" },
    { value: "rendimentos", label: "Rendimentos" }
  ];
  const tiposOperacoes = [
    { value: "compra", label: "Compra" },
    { value: "venda", label: "Venda" }
  ];
  const tiposDerivativo = [
    { value: "call", label: "CALL (Op\xE7\xE3o de Compra)" },
    { value: "put", label: "PUT (Op\xE7\xE3o de Venda)" }
  ];
  const statusOpcoes = [
    { value: "aberta", label: "Aberta" },
    { value: "exercida", label: "Exercida" },
    { value: "expirada", label: "Expirada" }
  ];
  const ativosPorTipo = {
    acoes: ["PETR4", "VALE3", "ITUB4", "ABEV3", "BBDC4", "WEGE3", "MGLU3", "RENT3", "SUZB3", "JBSS3", "GOAU4", "BBAS3"],
    fundos_imobiliarios: ["HGLG11", "KNRI11", "XPML11", "VISC11", "BCFF11", "MXRF11", "HGRU11", "GALG11", "KNCR11", "GGRC11"],
    criptomoedas: ["Bitcoin (BTC)", "Ethereum (ETH)", "Binance Coin (BNB)", "Cardano (ADA)", "Solana (SOL)", "Polkadot (DOT)", "Chainlink (LINK)", "Polygon (MATIC)", "Avalanche (AVAX)", "Uniswap (UNI)"],
    fundos_investimento: ["Fundo XP Multi", "Fundo BTG RF", "Fundo Bradesco FI", "Fundo Ita\xFA Multimercado", "Fundo Santander RF", "Fundo BB Multimercado", "Fundo Inter RF", "Fundo Modal Multimercado", "Fundo Warren FI", "Fundo Rico RF"],
    renda_fixa: ["Tesouro Selic 2028", "Tesouro IPCA+ 2030", "CDB Inter 110% CDI", "LCA Banco do Brasil", "LCI Bradesco", "Debenture Petrobras", "CRA Securitizadora", "CRI Habitat", "Tesouro Prefixado 2027", "LC Banco Original", "Tesouro Selic 2029"],
    etfs: ["BOVA11", "IVVB11", "SMAL11", "DIVO11", "FIND11", "XINA11", "SPXI11", "MATB11", "ISUS11", "ECOO11"]
  };
  const calcularValorTotal = () => {
    const quantidade = parseFloat(formData.quantidade) || 0;
    const preco = parseFloat(formData.preco) || 0;
    const outrosCustos = parseFloat(formData.outros_custos) || 0;
    return quantidade * preco + outrosCustos;
  };
  const calcularValorTotalDerivativo = () => {
    const quantidade = parseFloat(derivativoData.quantidade) || 0;
    const preco = parseFloat(derivativoData.preco) || 0;
    const outrosCustos = parseFloat(derivativoData.outros_custos) || 0;
    return quantidade * preco + outrosCustos;
  };
  const validarFormulario = () => {
    const newErrors = {};
    if (!formData.tipo_ativo) newErrors.tipo_ativo = "Tipo de ativo \xE9 obrigat\xF3rio";
    if (!formData.ativo) newErrors.ativo = "Ativo \xE9 obrigat\xF3rio";
    if (!formData.data) newErrors.data = "Data \xE9 obrigat\xF3ria";
    if (!formData.quantidade || formData.quantidade <= 0) newErrors.quantidade = "Quantidade deve ser maior que 0";
    if (!formData.preco || formData.preco <= 0) newErrors.preco = "Pre\xE7o deve ser maior que 0";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validarFormulario()) return;
    setIsSubmitting(true);
    const itemData = {
      tipo_ativo: formData.tipo_ativo,
      ativo: formData.ativo,
      data: formData.data,
      quantidade: parseFloat(formData.quantidade),
      preco: parseFloat(formData.preco),
      outros_custos: parseFloat(formData.outros_custos) || 0,
      valor_total: calcularValorTotal()
    };
    try {
      if (editingId) {
        const tableName = activeTab === "compra" ? "investimentos_compras" : "investimentos_vendas";
        const { data, error } = await supabase.from(tableName).update(itemData).eq("id", editingId).select();
        if (error) {
          throw error;
        }
        if (activeTab === "compra") {
          setCompras(compras.map((item) => item.id === editingId ? data[0] : item));
        } else {
          setVendas(vendas.map((item) => item.id === editingId ? data[0] : item));
        }
        setEditingId(null);
      } else {
        const tableName = activeTab === "compra" ? "investimentos_compras" : "investimentos_vendas";
        const { data, error } = await supabase.from(tableName).insert([itemData]).select();
        if (error) {
          throw error;
        }
        if (activeTab === "compra") {
          setCompras([data[0], ...compras]);
        } else {
          setVendas([data[0], ...vendas]);
        }
      }
      setImportMessage(`\u2705 ${activeTab === "compra" ? "Compra" : "Venda"} ${editingId ? "atualizada" : "adicionada"} com sucesso!`);
      setTimeout(() => setImportMessage(""), 3e3);
    } catch (error) {
      console.error("Erro ao salvar no Supabase:", error);
      setImportMessage(`\u274C Erro ao ${editingId ? "atualizar" : "adicionar"} ${activeTab === "compra" ? "compra" : "venda"}. Tente novamente.`);
      setTimeout(() => setImportMessage(""), 5e3);
    }
    setFormData({
      tipo_ativo: "",
      ativo: "",
      data: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      quantidade: "",
      preco: "",
      outros_custos: ""
    });
    setIsSubmitting(false);
  };
  const handleEdit = (item) => {
    setFormData({
      tipo_ativo: item.tipo_ativo,
      ativo: item.ativo,
      data: item.data,
      quantidade: item.quantidade.toString(),
      preco: item.preco.toString(),
      outros_custos: item.outros_custos.toString()
    });
    setEditingId(item.id);
  };
  const handleDelete = async (id) => {
    if (window.confirm("Tem certeza que deseja excluir esta transa\xE7\xE3o?")) {
      try {
        const tableName = activeTab === "compra" ? "investimentos_compras" : "investimentos_vendas";
        const { error } = await supabase.from(tableName).delete().eq("id", id);
        if (error) {
          throw error;
        }
        if (activeTab === "compra") {
          setCompras(compras.filter((item) => item.id !== id));
        } else {
          setVendas(vendas.filter((item) => item.id !== id));
        }
        setImportMessage(`\u2705 ${activeTab === "compra" ? "Compra" : "Venda"} exclu\xEDda com sucesso!`);
        setTimeout(() => setImportMessage(""), 3e3);
      } catch (error) {
        console.error("Erro ao excluir do Supabase:", error);
        setImportMessage(`\u274C Erro ao excluir ${activeTab === "compra" ? "compra" : "venda"}. Tente novamente.`);
        setTimeout(() => setImportMessage(""), 5e3);
      }
    }
  };
  const handleCancelEdit = () => {
    setEditingId(null);
    setFormData({
      tipo_ativo: "",
      ativo: "",
      data: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      quantidade: "",
      preco: "",
      outros_custos: ""
    });
    setErrors({});
  };
  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value
    }));
    if (errors[field]) {
      setErrors((prev) => ({
        ...prev,
        [field]: void 0
      }));
    }
    if (field === "tipo_ativo") {
      setFormData((prev) => ({
        ...prev,
        ativo: ""
      }));
    }
  };
  const getEstatisticas = () => {
    const totalCompras = compras.reduce((sum, item) => sum + item.valor_total, 0);
    const totalVendas = vendas.reduce((sum, item) => sum + item.valor_total, 0);
    const totalProventos = proventos.filter((p) => !p.a_receber).reduce((sum, item) => sum + item.valor * (item.quantidade || 1), 0);
    const proventosAReceber = proventos.filter((p) => p.a_receber).reduce((sum, item) => sum + item.valor * (item.quantidade || 1), 0);
    const derivativosRecebidos = derivativos.filter((d) => d.tipo_operacao === "venda" && d.tipo_derivativo === "call").reduce((sum, item) => sum + item.valor_total, 0);
    const carteiraData = getCarteiraData();
    const valorMercadoTotal = carteiraData.filter((item) => item.quantidadeTotal > 0 && item.valorAtual > 0).reduce((sum, item) => sum + item.valorMercado, 0);
    const totalInvestidoAtual = carteiraData.filter((item) => item.quantidadeTotal > 0).reduce((sum, item) => sum + item.quantidadeTotal * item.precoMedio, 0);
    const saldoLiquido = valorMercadoTotal - totalInvestidoAtual;
    return {
      totalCompras,
      totalVendas,
      saldoLiquido,
      valorMercadoTotal,
      totalInvestidoAtual,
      totalTransacoes: compras.length + vendas.length,
      totalProventos,
      proventosAReceber,
      derivativosRecebidos
    };
  };
  const getAtivosUnicos = () => {
    const ativosCompras = compras.map((item) => item.ativo);
    const ativosVendas = vendas.map((item) => item.ativo);
    return [.../* @__PURE__ */ new Set([...ativosCompras, ...ativosVendas])];
  };
  const getDadosGraficos = () => {
    const proventosPorMes = Array.from({ length: 12 }, (_, i) => {
      const data = /* @__PURE__ */ new Date();
      data.setMonth(data.getMonth() - (11 - i));
      const mes = data.getMonth() + 1;
      const ano = data.getFullYear();
      const valorMes = proventos.filter((p) => !p.a_receber).filter((p) => {
        if (!p.data) return false;
        const dataProvento = /* @__PURE__ */ new Date(p.data + "T12:00:00");
        const mesProvento = dataProvento.getMonth() + 1;
        const anoProvento = dataProvento.getFullYear();
        return mesProvento === mes && anoProvento === ano;
      }).reduce((sum, p) => sum + (p.valor || 0) * (p.quantidade || 1), 0);
      return {
        mes: data.toLocaleDateString("pt-BR", { month: "short", year: "2-digit" }).replace(".", ""),
        mesCompleto: data.toLocaleDateString("pt-BR", { month: "long", year: "numeric" }),
        mesFormatado: `${data.toLocaleDateString("pt-BR", { month: "short" }).replace(".", "")}/${ano}`,
        valor: valorMes,
        ano,
        mesNumero: mes
      };
    });
    const ativosValorInvestido = {};
    compras.forEach((compra) => {
      if (!ativosValorInvestido[compra.ativo]) {
        ativosValorInvestido[compra.ativo] = {
          ativo: compra.ativo,
          valorCompras: 0,
          valorVendas: 0,
          quantidadeComprada: 0,
          quantidadeVendida: 0
        };
      }
      ativosValorInvestido[compra.ativo].valorCompras += compra.valor_total;
      ativosValorInvestido[compra.ativo].quantidadeComprada += compra.quantidade;
    });
    vendas.forEach((venda) => {
      if (ativosValorInvestido[venda.ativo]) {
        ativosValorInvestido[venda.ativo].valorVendas += venda.valor_total;
        ativosValorInvestido[venda.ativo].quantidadeVendida += venda.quantidade;
      }
    });
    const distribuicaoAtivos = Object.values(ativosValorInvestido).map((item) => {
      const quantidadeAtual = item.quantidadeComprada - item.quantidadeVendida;
      const precoMedio = item.quantidadeComprada > 0 ? item.valorCompras / item.quantidadeComprada : 0;
      const valorInvestidoAtual = quantidadeAtual * precoMedio;
      return {
        ativo: item.ativo,
        valorInvestido: valorInvestidoAtual,
        quantidade: quantidadeAtual
      };
    }).filter((item) => item.quantidade > 0 && item.valorInvestido > 0).sort((a, b) => b.valorInvestido - a.valorInvestido).slice(0, 6);
    const totalInvestido = distribuicaoAtivos.reduce((sum, item) => sum + item.valorInvestido, 0);
    const distribuicaoAtivosComPorcentagem = distribuicaoAtivos.map((item) => ({
      ...item,
      porcentagem: totalInvestido > 0 ? (item.valorInvestido / totalInvestido * 100).toFixed(1) : 0
    }));
    return { proventosPorMes, distribuicaoAtivos: distribuicaoAtivosComPorcentagem };
  };
  const getProventosPorAtivo = () => {
    const proventosPorAtivo2 = {};
    proventos.forEach((provento) => {
      if (!proventosPorAtivo2[provento.ativo]) {
        proventosPorAtivo2[provento.ativo] = {
          ativo: provento.ativo,
          totalRecebido: 0,
          totalAReceber: 0,
          totalGeral: 0,
          quantidadeOperacoes: 0
        };
      }
      const valorCalculado = provento.valor * (provento.quantidade || 1);
      proventosPorAtivo2[provento.ativo].quantidadeOperacoes += 1;
      proventosPorAtivo2[provento.ativo].totalGeral += valorCalculado;
      if (provento.a_receber) {
        proventosPorAtivo2[provento.ativo].totalAReceber += valorCalculado;
      } else {
        proventosPorAtivo2[provento.ativo].totalRecebido += valorCalculado;
      }
    });
    return Object.values(proventosPorAtivo2).sort((a, b) => b.totalGeral - a.totalGeral).slice(0, 10);
  };
  const getDerivativosPorAtivo = () => {
    const derivativosPorAtivo2 = {};
    derivativos.forEach((derivativo) => {
      if (!derivativosPorAtivo2[derivativo.ativo_subjacente]) {
        derivativosPorAtivo2[derivativo.ativo_subjacente] = {
          ativo: derivativo.ativo_subjacente,
          totalCompras: 0,
          totalVendas: 0,
          totalGeral: 0,
          quantidadeOperacoes: 0,
          opcoes: {
            calls: { compras: 0, vendas: 0 },
            puts: { compras: 0, vendas: 0 }
          }
        };
      }
      const item = derivativosPorAtivo2[derivativo.ativo_subjacente];
      item.quantidadeOperacoes += 1;
      item.totalGeral += derivativo.valor_total;
      if (derivativo.tipo_operacao === "compra") {
        item.totalCompras += derivativo.valor_total;
      } else {
        item.totalVendas += derivativo.valor_total;
      }
      if (derivativo.tipo_derivativo === "call") {
        if (derivativo.tipo_operacao === "compra") {
          item.opcoes.calls.compras += derivativo.valor_total;
        } else {
          item.opcoes.calls.vendas += derivativo.valor_total;
        }
      } else {
        if (derivativo.tipo_operacao === "compra") {
          item.opcoes.puts.compras += derivativo.valor_total;
        } else {
          item.opcoes.puts.vendas += derivativo.valor_total;
        }
      }
    });
    return Object.values(derivativosPorAtivo2).sort((a, b) => b.totalGeral - a.totalGeral).slice(0, 10);
  };
  const handleProventoSubmit = async (e) => {
    e.preventDefault();
    const newErrors = {};
    if (!proventoData.tipo_provento) newErrors.tipo_provento = "Tipo de provento \xE9 obrigat\xF3rio";
    if (!proventoData.ativo) newErrors.ativo = "Ativo \xE9 obrigat\xF3rio";
    if (!proventoData.data) newErrors.data = "Data \xE9 obrigat\xF3ria";
    if (!proventoData.valor || proventoData.valor <= 0) newErrors.valor = "Valor deve ser maior que 0";
    setProventoErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;
    setIsSubmitting(true);
    const proventoDataToSave = {
      tipo_provento: proventoData.tipo_provento,
      ativo: proventoData.ativo,
      data: proventoData.data,
      valor: parseFloat(proventoData.valor),
      quantidade: parseFloat(proventoData.quantidade) || 0,
      a_receber: proventoData.a_receber
    };
    try {
      if (editingProventoId) {
        const { data, error } = await supabase.from("investimentos_proventos").update(proventoDataToSave).eq("id", editingProventoId).select();
        if (error) {
          throw error;
        }
        setProventos(proventos.map((item) => item.id === editingProventoId ? data[0] : item));
        setEditingProventoId(null);
      } else {
        const { data, error } = await supabase.from("investimentos_proventos").insert([proventoDataToSave]).select();
        if (error) {
          throw error;
        }
        setProventos([data[0], ...proventos]);
      }
      setImportMessage(`\u2705 Provento ${editingProventoId ? "atualizado" : "adicionado"} com sucesso!`);
      setTimeout(() => setImportMessage(""), 3e3);
    } catch (error) {
      console.error("Erro ao salvar provento no Supabase:", error);
      setImportMessage(`\u274C Erro ao ${editingProventoId ? "atualizar" : "adicionar"} provento. Tente novamente.`);
      setTimeout(() => setImportMessage(""), 5e3);
    }
    setProventoData({
      tipo_provento: "",
      ativo: "",
      data: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      valor: "",
      quantidade: "",
      a_receber: false
    });
    setIsSubmitting(false);
  };
  const handleEditProvento = (provento) => {
    setProventoData({
      tipo_provento: provento.tipo_provento,
      ativo: provento.ativo,
      data: provento.data,
      valor: provento.valor.toString(),
      quantidade: provento.quantidade.toString(),
      a_receber: provento.a_receber
    });
    setEditingProventoId(provento.id);
  };
  const handleDeleteProvento = async (id) => {
    if (window.confirm("Tem certeza que deseja excluir este provento?")) {
      try {
        const { error } = await supabase.from("investimentos_proventos").delete().eq("id", id);
        if (error) {
          throw error;
        }
        setProventos(proventos.filter((item) => item.id !== id));
        setImportMessage("\u2705 Provento exclu\xEDdo com sucesso!");
        setTimeout(() => setImportMessage(""), 3e3);
      } catch (error) {
        console.error("Erro ao excluir provento do Supabase:", error);
        setImportMessage("\u274C Erro ao excluir provento. Tente novamente.");
        setTimeout(() => setImportMessage(""), 5e3);
      }
    }
  };
  const handleCancelEditProvento = () => {
    setEditingProventoId(null);
    setProventoData({
      tipo_provento: "",
      ativo: "",
      data: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      valor: "",
      quantidade: "",
      a_receber: false
    });
    setProventoErrors({});
  };
  const getProventosFiltrados = () => {
    return proventos.filter((p) => {
      const dataProvento = /* @__PURE__ */ new Date(p.data + "T12:00:00");
      const anoProvento = dataProvento.getFullYear();
      return (!filters.tipo_provento || p.tipo_provento === filters.tipo_provento) && (!filters.ativo || p.ativo === filters.ativo) && anoProvento === filters.ano;
    });
  };
  useEffect(() => {
    if (!autoUpdateEnabled) return;
    const interval = setInterval(() => {
      if (activeTab === "carteira") {
        const carteiraData = getCarteiraData();
        const acoesNaCarteira = carteiraData.filter((item) => item.tipo_ativo === "acoes" && item.quantidadeTotal > 0);
        if (acoesNaCarteira.length > 0) {
          updateStockPricesFromAPI();
        }
      }
    }, 5 * 60 * 1e3);
    return () => clearInterval(interval);
  }, [autoUpdateEnabled]);
  const handleDerivativoSubmit = async (e) => {
    e.preventDefault();
    const newErrors = {};
    if (!derivativoData.tipo_operacao) newErrors.tipo_operacao = "Tipo de opera\xE7\xE3o \xE9 obrigat\xF3rio";
    if (!derivativoData.tipo_derivativo) newErrors.tipo_derivativo = "Tipo de derivativo \xE9 obrigat\xF3rio";
    if (!derivativoData.ativo_subjacente) newErrors.ativo_subjacente = "Ativo subjacente \xE9 obrigat\xF3rio";
    if (!derivativoData.codigo_opcao) newErrors.codigo_opcao = "C\xF3digo da op\xE7\xE3o \xE9 obrigat\xF3rio";
    if (!derivativoData.strike || derivativoData.strike <= 0) newErrors.strike = "Strike deve ser maior que 0";
    if (!derivativoData.data) newErrors.data = "Data \xE9 obrigat\xF3ria";
    if (!derivativoData.quantidade || derivativoData.quantidade <= 0) newErrors.quantidade = "Quantidade deve ser maior que 0";
    if (!derivativoData.preco || derivativoData.preco <= 0) newErrors.preco = "Pre\xE7o deve ser maior que 0";
    setDerivativoErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;
    setIsSubmitting(true);
    const derivativoDataToSave = {
      tipo_operacao: derivativoData.tipo_operacao,
      tipo_derivativo: derivativoData.tipo_derivativo,
      ativo_subjacente: derivativoData.ativo_subjacente,
      codigo_opcao: derivativoData.codigo_opcao,
      strike: parseFloat(derivativoData.strike),
      data: derivativoData.data,
      quantidade: parseFloat(derivativoData.quantidade),
      preco: parseFloat(derivativoData.preco),
      outros_custos: parseFloat(derivativoData.outros_custos) || 0,
      status: derivativoData.status,
      valor_total: calcularValorTotalDerivativo()
    };
    try {
      if (editingDerivativoId) {
        const { data, error } = await supabase.from("investimentos_derivativos").update(derivativoDataToSave).eq("id", editingDerivativoId).select();
        if (error) {
          throw error;
        }
        setDerivativos(derivativos.map((item) => item.id === editingDerivativoId ? data[0] : item));
        setEditingDerivativoId(null);
      } else {
        const { data, error } = await supabase.from("investimentos_derivativos").insert([derivativoDataToSave]).select();
        if (error) {
          throw error;
        }
        setDerivativos([data[0], ...derivativos]);
      }
      setImportMessage(`\u2705 Derivativo ${editingDerivativoId ? "atualizado" : "adicionado"} com sucesso!`);
      setTimeout(() => setImportMessage(""), 3e3);
    } catch (error) {
      console.error("Erro ao salvar derivativo no Supabase:", error);
      setImportMessage(`\u274C Erro ao ${editingDerivativoId ? "atualizar" : "adicionar"} derivativo. Tente novamente.`);
      setTimeout(() => setImportMessage(""), 5e3);
    }
    setDerivativoData({
      tipo_operacao: "",
      tipo_derivativo: "",
      ativo_subjacente: "",
      codigo_opcao: "",
      strike: "",
      data: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      quantidade: "",
      preco: "",
      outros_custos: "",
      status: "aberta"
    });
    setIsSubmitting(false);
  };
  const handleEditDerivativo = (derivativo) => {
    setDerivativoData({
      tipo_operacao: derivativo.tipo_operacao,
      tipo_derivativo: derivativo.tipo_derivativo,
      ativo_subjacente: derivativo.ativo_subjacente,
      codigo_opcao: derivativo.codigo_opcao,
      strike: derivativo.strike ? derivativo.strike.toString() : "",
      data: derivativo.data,
      quantidade: derivativo.quantidade.toString(),
      preco: derivativo.preco.toString(),
      outros_custos: derivativo.outros_custos.toString(),
      status: derivativo.status
    });
    setEditingDerivativoId(derivativo.id);
  };
  const handleDeleteDerivativo = async (id) => {
    if (window.confirm("Tem certeza que deseja excluir esta opera\xE7\xE3o?")) {
      try {
        const { error } = await supabase.from("investimentos_derivativos").delete().eq("id", id);
        if (error) {
          throw error;
        }
        setDerivativos(derivativos.filter((item) => item.id !== id));
        setImportMessage("\u2705 Derivativo exclu\xEDdo com sucesso!");
        setTimeout(() => setImportMessage(""), 3e3);
      } catch (error) {
        console.error("Erro ao excluir derivativo do Supabase:", error);
        setImportMessage("\u274C Erro ao excluir derivativo. Tente novamente.");
        setTimeout(() => setImportMessage(""), 5e3);
      }
    }
  };
  const handleCancelEditDerivativo = () => {
    setEditingDerivativoId(null);
    setDerivativoData({
      tipo_operacao: "",
      tipo_derivativo: "",
      ativo_subjacente: "",
      codigo_opcao: "",
      strike: "",
      data: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      quantidade: "",
      preco: "",
      outros_custos: "",
      status: "aberta"
    });
    setDerivativoErrors({});
  };
  const getCarteiraData = () => {
    const ativosMap = {};
    compras.forEach((compra) => {
      if (!ativosMap[compra.ativo]) {
        ativosMap[compra.ativo] = {
          ativo: compra.ativo,
          tipo_ativo: compra.tipo_ativo,
          totalComprado: 0,
          quantidadeComprada: 0,
          valorTotalCompras: 0,
          totalVendido: 0,
          quantidadeVendida: 0,
          valorTotalVendas: 0
        };
      }
      ativosMap[compra.ativo].quantidadeComprada += compra.quantidade;
      ativosMap[compra.ativo].valorTotalCompras += compra.valor_total;
    });
    vendas.forEach((venda) => {
      if (ativosMap[venda.ativo]) {
        ativosMap[venda.ativo].quantidadeVendida += venda.quantidade;
        ativosMap[venda.ativo].valorTotalVendas += venda.valor_total;
      }
    });
    const carteiraData = Object.values(ativosMap).map((item) => {
      const quantidadeTotal = item.quantidadeComprada - item.quantidadeVendida;
      const precoMedio = item.quantidadeComprada > 0 ? item.valorTotalCompras / item.quantidadeComprada : 0;
      const custoVendas = item.quantidadeVendida * precoMedio;
      const lucroPrejuizo = item.valorTotalVendas - custoVendas;
      const retornoPercentual = custoVendas > 0 ? lucroPrejuizo / custoVendas * 100 : 0;
      const valorAtual = valoresAtuais[item.ativo] || 0;
      const valorMercado = quantidadeTotal * valorAtual;
      const valorInvestidoAtual = quantidadeTotal * precoMedio;
      const lucroPrejuizoLatente = valorMercado - valorInvestidoAtual;
      const retornoPercentualLatente = valorInvestidoAtual > 0 ? lucroPrejuizoLatente / valorInvestidoAtual * 100 : 0;
      return {
        ...item,
        quantidadeTotal,
        precoMedio,
        lucroPrejuizo,
        retornoPercentual: isFinite(retornoPercentual) ? retornoPercentual : 0,
        valorAtual,
        valorMercado,
        lucroPrejuizoLatente,
        retornoPercentualLatente: isFinite(retornoPercentualLatente) ? retornoPercentualLatente : 0
      };
    });
    let dadosFiltrados = carteiraData;
    if (carteiraFilters.tipo_ativo) {
      dadosFiltrados = dadosFiltrados.filter((item) => item.tipo_ativo === carteiraFilters.tipo_ativo);
    }
    if (carteiraFilters.busca) {
      dadosFiltrados = dadosFiltrados.filter(
        (item) => item.ativo.toLowerCase().includes(carteiraFilters.busca.toLowerCase())
      );
    }
    if (carteiraFilters.periodo) {
      const hoje = /* @__PURE__ */ new Date();
      let dataCorte = /* @__PURE__ */ new Date();
      switch (carteiraFilters.periodo) {
        case "30dias":
          dataCorte.setDate(hoje.getDate() - 30);
          break;
        case "6meses":
          dataCorte.setMonth(hoje.getMonth() - 6);
          break;
        case "ano":
          dataCorte.setFullYear(hoje.getFullYear(), 0, 1);
          break;
        default:
          dataCorte = /* @__PURE__ */ new Date("1900-01-01");
      }
      dadosFiltrados = dadosFiltrados.filter((item) => {
        const comprasRecentes = compras.filter(
          (c) => c.ativo === item.ativo && /* @__PURE__ */ new Date(c.data + "T12:00:00") >= dataCorte
        );
        const vendasRecentes = vendas.filter(
          (v) => v.ativo === item.ativo && /* @__PURE__ */ new Date(v.data + "T12:00:00") >= dataCorte
        );
        return comprasRecentes.length > 0 || vendasRecentes.length > 0;
      });
    }
    if (sortConfig.key) {
      dadosFiltrados.sort((a, b) => {
        const aVal = a[sortConfig.key];
        const bVal = b[sortConfig.key];
        if (aVal < bVal) return sortConfig.direction === "asc" ? -1 : 1;
        if (aVal > bVal) return sortConfig.direction === "asc" ? 1 : -1;
        return 0;
      });
    }
    return dadosFiltrados;
  };
  const handleSort = (key) => {
    let direction = "asc";
    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }
    setSortConfig({ key, direction });
  };
  const getSortIcon = (columnKey) => {
    if (sortConfig.key !== columnKey) {
      return /* @__PURE__ */ React.createElement("span", { className: "text-gray-400" }, "\u2195");
    }
    return sortConfig.direction === "asc" ? /* @__PURE__ */ React.createElement("span", { className: "text-blue-400" }, "\u2191") : /* @__PURE__ */ React.createElement("span", { className: "text-blue-400" }, "\u2193");
  };
  const handleEditValorAtual = (ativo, valorAtual) => {
    setEditingValorAtivo(ativo);
    setValorAtualTemp(valorAtual.toString());
  };
  const handleSaveValorAtual = (ativo) => {
    const novoValor = parseFloat(valorAtualTemp) || 0;
    setValoresAtuais({
      ...valoresAtuais,
      [ativo]: novoValor
    });
    setEditingValorAtivo(null);
    setValorAtualTemp("");
  };
  const handleCancelEditValorAtual = () => {
    setEditingValorAtivo(null);
    setValorAtualTemp("");
  };
  const updateStockPricesFromAPI = async () => {
    if (activeTab !== "carteira") {
      return;
    }
    setIsUpdatingPrices(true);
    setPriceUpdateMessage("\u{1F504} Buscando cota\xE7\xF5es atualizadas...");
    try {
      const carteiraData = getCarteiraData();
      const acoesNaCarteira = carteiraData.filter((item) => item.tipo_ativo === "acoes" && item.quantidadeTotal > 0).map((item) => item.ativo);
      if (acoesNaCarteira.length === 0) {
        setPriceUpdateMessage("\u2139\uFE0F Nenhuma a\xE7\xE3o encontrada na carteira para atualizar.");
        setTimeout(() => setPriceUpdateMessage(""), 3e3);
        setIsUpdatingPrices(false);
        return;
      }
      const token = "sb9Cd84Y9hW5eRharMMRuD";
      const updatedPrices = {};
      let successCount = 0;
      let errorCount = 0;
      for (const symbol of acoesNaCarteira) {
        if (activeTab !== "carteira") {
          setIsUpdatingPrices(false);
          setPriceUpdateMessage("");
          return;
        }
        try {
          const url = `https://brapi.dev/api/quote/${symbol}?token=${token}`;
          const response = await fetch(url);
          if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
          }
          const data = await response.json();
          if (data.results && data.results.length > 0) {
            const stockData = data.results[0];
            if (stockData.regularMarketPrice && stockData.regularMarketPrice > 0) {
              updatedPrices[symbol] = stockData.regularMarketPrice;
              successCount++;
            }
          }
          await new Promise((resolve) => setTimeout(resolve, 100));
        } catch (error) {
          console.error(`Erro ao buscar pre\xE7o de ${symbol}:`, error);
          errorCount++;
        }
      }
      if (Object.keys(updatedPrices).length > 0) {
        setValoresAtuais((prev) => ({
          ...prev,
          ...updatedPrices
        }));
        setLastUpdateTime((/* @__PURE__ */ new Date()).toISOString());
        setPriceUpdateMessage(
          `\u2705 Cota\xE7\xF5es atualizadas! ${successCount} sucessos${errorCount > 0 ? `, ${errorCount} erros` : ""}`
        );
      } else {
        setPriceUpdateMessage("\u26A0\uFE0F Nenhum pre\xE7o p\xF4de ser atualizado. Verifique sua conex\xE3o.");
      }
    } catch (error) {
      console.error("Erro geral na atualiza\xE7\xE3o de pre\xE7os:", error);
      setPriceUpdateMessage("\u274C Erro ao conectar com a API de cota\xE7\xF5es.");
    }
    setIsUpdatingPrices(false);
    setTimeout(() => setPriceUpdateMessage(""), 5e3);
  };
  const updateSingleStockPrice = async (symbol) => {
    setUpdatingSingleStock(symbol);
    try {
      const token = "sb9Cd84Y9hW5eRharMMRuD";
      const url = `https://brapi.dev/api/quote/${symbol}?token=${token}`;
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const data = await response.json();
      if (data.results && data.results.length > 0) {
        const stockData = data.results[0];
        if (stockData.regularMarketPrice && stockData.regularMarketPrice > 0) {
          setValoresAtuais((prev) => ({
            ...prev,
            [symbol]: stockData.regularMarketPrice
          }));
          setPriceUpdateMessage(`\u2705 ${symbol}: R$ ${stockData.regularMarketPrice.toLocaleString("pt-BR", { minimumFractionDigits: 2 })} atualizado!`);
          setTimeout(() => setPriceUpdateMessage(""), 3e3);
          return stockData.regularMarketPrice;
        }
      }
      throw new Error("Pre\xE7o n\xE3o encontrado na resposta da API");
    } catch (error) {
      console.error(`Erro ao buscar pre\xE7o de ${symbol}:`, error);
      setPriceUpdateMessage(`\u274C Erro ao atualizar ${symbol}. Tente novamente.`);
      setTimeout(() => setPriceUpdateMessage(""), 3e3);
      throw error;
    } finally {
      setUpdatingSingleStock(null);
    }
  };
  const formatLastUpdateTime = () => {
    if (!lastUpdateTime) return "Nunca";
    const updateDate = new Date(lastUpdateTime);
    const now = /* @__PURE__ */ new Date();
    const diffMinutes = Math.floor((now - updateDate) / (1e3 * 60));
    if (diffMinutes < 1) return "Agora mesmo";
    if (diffMinutes < 60) return `${diffMinutes} min atr\xE1s`;
    if (diffMinutes < 1440) return `${Math.floor(diffMinutes / 60)}h atr\xE1s`;
    return updateDate.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };
  const [exportMessage, setExportMessage] = useState("");
  const [importMessage, setImportMessage] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const loadDataFromSupabase = async () => {
    setIsLoading(true);
    setConnectionStatus("connecting");
    try {
      console.log("\u{1F504} Iniciando conex\xE3o com Supabase...");
      setImportMessage("\u{1F504} Conectando ao Supabase...");
      const { data: testData, error: testError } = await supabase.from("investimentos_compras").select("count", { count: "exact", head: true });
      if (testError) {
        console.error("\u274C Erro ao testar conex\xE3o:", testError);
        setConnectionStatus("error");
        setImportMessage(`\u274C Erro de conex\xE3o: ${testError.message}`);
        setTimeout(() => setImportMessage(""), 8e3);
        setIsLoading(false);
        return;
      }
      console.log("\u2705 Conex\xE3o estabelecida com sucesso!");
      setConnectionStatus("connected");
      setImportMessage("\u2705 Conectado! Carregando dados das tabelas...");
      let totalRegistros = 0;
      console.log("\u{1F4E6} Carregando compras...");
      const { data: comprasData, error: comprasError } = await supabase.from("investimentos_compras").select("*").order("created_at", { ascending: false });
      if (comprasError) {
        console.error("\u274C Erro ao carregar compras:", comprasError);
        setImportMessage(`\u274C Erro ao carregar compras: ${comprasError.message}`);
      } else {
        setCompras(comprasData || []);
        totalRegistros += comprasData?.length || 0;
        console.log(`\u2705 ${comprasData?.length || 0} compras carregadas`);
      }
      console.log("\u{1F4B0} Carregando vendas...");
      const { data: vendasData, error: vendasError } = await supabase.from("investimentos_vendas").select("*").order("created_at", { ascending: false });
      if (vendasError) {
        console.error("\u274C Erro ao carregar vendas:", vendasError);
        setImportMessage(`\u274C Erro ao carregar vendas: ${vendasError.message}`);
      } else {
        setVendas(vendasData || []);
        totalRegistros += vendasData?.length || 0;
        console.log(`\u2705 ${vendasData?.length || 0} vendas carregadas`);
      }
      console.log("\u{1F381} Carregando proventos...");
      const { data: proventosData, error: proventosError } = await supabase.from("investimentos_proventos").select("*").order("created_at", { ascending: false });
      if (proventosError) {
        console.error("\u274C Erro ao carregar proventos:", proventosError);
        setImportMessage(`\u274C Erro ao carregar proventos: ${proventosError.message}`);
      } else {
        setProventos(proventosData || []);
        totalRegistros += proventosData?.length || 0;
        console.log(`\u2705 ${proventosData?.length || 0} proventos carregados`);
      }
      console.log("\u{1F3AF} Carregando derivativos...");
      const { data: derivativosData, error: derivativosError } = await supabase.from("investimentos_derivativos").select("*").order("created_at", { ascending: false });
      if (derivativosError) {
        console.error("\u274C Erro ao carregar derivativos:", derivativosError);
        setImportMessage(`\u274C Erro ao carregar derivativos: ${derivativosError.message}`);
      } else {
        setDerivativos(derivativosData || []);
        totalRegistros += derivativosData?.length || 0;
        console.log(`\u2705 ${derivativosData?.length || 0} derivativos carregados`);
      }
      const mensagemSucesso = `\u2705 Sincroniza\xE7\xE3o completa! Total: ${totalRegistros} registros carregados | Compras: ${comprasData?.length || 0} | Vendas: ${vendasData?.length || 0} | Proventos: ${proventosData?.length || 0} | Derivativos: ${derivativosData?.length || 0}`;
      console.log(mensagemSucesso);
      setImportMessage(mensagemSucesso);
      setTimeout(() => setImportMessage(""), 8e3);
    } catch (error) {
      console.error("\u{1F4A5} Erro geral ao carregar dados:", error);
      setConnectionStatus("error");
      setImportMessage(`\u274C Erro inesperado: ${error.message}`);
      setTimeout(() => setImportMessage(""), 8e3);
    }
    setIsLoading(false);
  };
  useEffect(() => {
    loadDataFromSupabase();
  }, []);
  const testSupabaseConnection = async () => {
    setIsLoading(true);
    setImportMessage("\u{1F504} Testando conex\xE3o com Supabase...");
    try {
      const { data, error } = await supabase.from("investimentos_compras").select("count", { count: "exact", head: true });
      if (error) {
        throw error;
      }
      setImportMessage("\u2705 Conex\xE3o com Supabase funcionando! Carregando dados...");
      setTimeout(() => {
        loadDataFromSupabase();
      }, 1e3);
    } catch (error) {
      console.error("Erro de conex\xE3o:", error);
      setImportMessage(`\u274C Erro de conex\xE3o: ${error.message}`);
      setTimeout(() => setImportMessage(""), 5e3);
    }
    setIsLoading(false);
  };
  const downloadCSV = (data, filename) => {
    const csvContent = data.join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    if (link.download !== void 0) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", filename);
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };
  const exportCompras = () => {
    if (compras.length === 0) {
      setExportMessage("Nenhuma compra para exportar.");
      setTimeout(() => setExportMessage(""), 3e3);
      return;
    }
    const headers = ["tipo_ativo", "ativo", "data", "quantidade", "preco", "outros_custos", "valor_total"];
    const csvData = [headers.join(",")];
    compras.forEach((item) => {
      const row = [
        item.tipo_ativo,
        item.ativo,
        item.data,
        item.quantidade,
        item.preco,
        item.outros_custos,
        item.valor_total
      ];
      csvData.push(row.join(","));
    });
    downloadCSV(csvData, "compras_TEK.csv");
    setExportMessage(`\u2705 ${compras.length} compras exportadas com sucesso!`);
    setTimeout(() => setExportMessage(""), 3e3);
  };
  const exportVendas = () => {
    if (vendas.length === 0) {
      setExportMessage("Nenhuma venda para exportar.");
      setTimeout(() => setExportMessage(""), 3e3);
      return;
    }
    const headers = ["tipo_ativo", "ativo", "data", "quantidade", "preco", "outros_custos", "valor_total"];
    const csvData = [headers.join(",")];
    vendas.forEach((item) => {
      const row = [
        item.tipo_ativo,
        item.ativo,
        item.data,
        item.quantidade,
        item.preco,
        item.outros_custos,
        item.valor_total
      ];
      csvData.push(row.join(","));
    });
    downloadCSV(csvData, "vendas_TEK.csv");
    setExportMessage(`\u2705 ${vendas.length} vendas exportadas com sucesso!`);
    setTimeout(() => setExportMessage(""), 3e3);
  };
  const exportProventos = () => {
    if (proventos.length === 0) {
      setExportMessage("Nenhum provento para exportar.");
      setTimeout(() => setExportMessage(""), 3e3);
      return;
    }
    const headers = ["tipo_provento", "ativo", "data", "valor", "quantidade", "a_receber"];
    const csvData = [headers.join(",")];
    proventos.forEach((item) => {
      const row = [
        item.tipo_provento,
        item.ativo,
        item.data,
        item.valor,
        item.quantidade || 0,
        item.a_receber ? "true" : "false"
      ];
      csvData.push(row.join(","));
    });
    downloadCSV(csvData, "proventos_TEK.csv");
    setExportMessage(`\u2705 ${proventos.length} proventos exportados com sucesso!`);
    setTimeout(() => setExportMessage(""), 3e3);
  };
  const exportDerivativos = () => {
    if (derivativos.length === 0) {
      setExportMessage("Nenhum derivativo para exportar.");
      setTimeout(() => setExportMessage(""), 3e3);
      return;
    }
    const headers = ["tipo_operacao", "tipo_derivativo", "ativo_subjacente", "codigo_opcao", "strike", "data", "quantidade", "preco", "outros_custos", "status", "valor_total"];
    const csvData = [headers.join(",")];
    derivativos.forEach((item) => {
      const row = [
        item.tipo_operacao,
        item.tipo_derivativo,
        item.ativo_subjacente,
        item.codigo_opcao,
        item.strike || 0,
        item.data,
        item.quantidade,
        item.preco,
        item.outros_custos,
        item.status,
        item.valor_total
      ];
      csvData.push(row.join(","));
    });
    downloadCSV(csvData, "derivativos_TEK.csv");
    setExportMessage(`\u2705 ${derivativos.length} derivativos exportados com sucesso!`);
    setTimeout(() => setExportMessage(""), 3e3);
  };
  const exportCarteiraConsolidada = () => {
    const carteiraData = getCarteiraData();
    if (carteiraData.length === 0) {
      setExportMessage("Nenhum dado de carteira para exportar.");
      setTimeout(() => setExportMessage(""), 3e3);
      return;
    }
    const headers = ["ativo", "tipo_ativo", "quantidade_total", "preco_medio", "valor_total_compras", "valor_total_vendas", "lucro_prejuizo", "retorno_percentual", "valor_atual", "valor_mercado", "lucro_prejuizo_latente", "retorno_percentual_latente"];
    const csvData = [headers.join(",")];
    carteiraData.forEach((item) => {
      const row = [
        item.ativo,
        item.tipo_ativo,
        item.quantidadeTotal,
        item.precoMedio,
        item.valorTotalCompras,
        item.valorTotalVendas,
        item.lucroPrejuizo,
        item.retornoPercentual,
        item.valorAtual,
        item.valorMercado,
        item.lucroPrejuizoLatente,
        item.retornoPercentualLatente
      ];
      csvData.push(row.join(","));
    });
    downloadCSV(csvData, "carteira_consolidada_TEK.csv");
    setExportMessage(`\u2705 Carteira consolidada exportada com sucesso!`);
    setTimeout(() => setExportMessage(""), 3e3);
  };
  const exportBackupCompleto = () => {
    setIsProcessing(true);
    setTimeout(() => {
      if (compras.length > 0) exportCompras();
    }, 100);
    setTimeout(() => {
      if (vendas.length > 0) exportVendas();
    }, 200);
    setTimeout(() => {
      if (proventos.length > 0) exportProventos();
    }, 300);
    setTimeout(() => {
      if (derivativos.length > 0) exportDerivativos();
    }, 400);
    setTimeout(() => {
      exportCarteiraConsolidada();
      setIsProcessing(false);
      setExportMessage("\u2705 Backup completo exportado! Verifique os downloads.");
      setTimeout(() => setExportMessage(""), 5e3);
    }, 500);
  };
  const parseCSV = (csvText) => {
    const lines = csvText.split("\n").filter((line) => line.trim());
    if (lines.length < 2) return [];
    const headers = lines[0].split(",").map((h) => h.trim());
    const data = [];
    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(",").map((v) => v.trim());
      if (values.length === headers.length) {
        const item = {};
        headers.forEach((header, index) => {
          item[header] = values[index];
        });
        data.push(item);
      }
    }
    return data;
  };
  const handleFileImport = (event, type) => {
    const file = event.target.files[0];
    if (!file) return;
    if (file.type !== "text/csv" && !file.name.endsWith(".csv")) {
      setImportMessage("\u274C Por favor, selecione um arquivo .CSV v\xE1lido.");
      setTimeout(() => setImportMessage(""), 3e3);
      return;
    }
    setIsProcessing(true);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const csvData = parseCSV(e.target.result);
        if (csvData.length === 0) {
          setImportMessage("\u274C Arquivo CSV vazio ou formato inv\xE1lido.");
          setIsProcessing(false);
          setTimeout(() => setImportMessage(""), 3e3);
          return;
        }
        switch (type) {
          case "compras":
            importComprasData(csvData);
            break;
          case "vendas":
            importVendasData(csvData);
            break;
          case "proventos":
            importProventosData(csvData);
            break;
          case "derivativos":
            importDerivativosData(csvData);
            break;
        }
      } catch (error) {
        setImportMessage("\u274C Erro ao processar o arquivo CSV.");
        setIsProcessing(false);
        setTimeout(() => setImportMessage(""), 3e3);
      }
    };
    reader.readAsText(file);
    event.target.value = "";
  };
  const importComprasData = (data) => {
    try {
      const requiredFields = ["tipo_ativo", "ativo", "data", "quantidade", "preco"];
      const validData = data.filter(
        (item) => requiredFields.every((field) => item[field] && item[field] !== "")
      );
      if (validData.length === 0) {
        setImportMessage("\u274C Nenhum dado v\xE1lido encontrado no arquivo de compras.");
        setIsProcessing(false);
        setTimeout(() => setImportMessage(""), 3e3);
        return;
      }
      const newCompras = validData.map((item) => ({
        id: Date.now() + Math.random(),
        tipo_ativo: item.tipo_ativo,
        ativo: item.ativo,
        data: item.data,
        quantidade: parseFloat(item.quantidade) || 0,
        preco: parseFloat(item.preco) || 0,
        outros_custos: parseFloat(item.outros_custos) || 0,
        valor_total: parseFloat(item.valor_total) || (parseFloat(item.quantidade) || 0) * (parseFloat(item.preco) || 0) + (parseFloat(item.outros_custos) || 0),
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }));
      setCompras([...compras, ...newCompras]);
      setImportMessage(`\u2705 ${newCompras.length} compras importadas com sucesso!`);
      setIsProcessing(false);
      setTimeout(() => setImportMessage(""), 3e3);
    } catch (error) {
      setImportMessage("\u274C Erro ao importar dados de compras.");
      setIsProcessing(false);
      setTimeout(() => setImportMessage(""), 3e3);
    }
  };
  const importVendasData = (data) => {
    try {
      const requiredFields = ["tipo_ativo", "ativo", "data", "quantidade", "preco"];
      const validData = data.filter(
        (item) => requiredFields.every((field) => item[field] && item[field] !== "")
      );
      if (validData.length === 0) {
        setImportMessage("\u274C Nenhum dado v\xE1lido encontrado no arquivo de vendas.");
        setIsProcessing(false);
        setTimeout(() => setImportMessage(""), 3e3);
        return;
      }
      const newVendas = validData.map((item) => ({
        id: Date.now() + Math.random(),
        tipo_ativo: item.tipo_ativo,
        ativo: item.ativo,
        data: item.data,
        quantidade: parseFloat(item.quantidade) || 0,
        preco: parseFloat(item.preco) || 0,
        outros_custos: parseFloat(item.outros_custos) || 0,
        valor_total: parseFloat(item.valor_total) || (parseFloat(item.quantidade) || 0) * (parseFloat(item.preco) || 0) + (parseFloat(item.outros_custos) || 0),
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }));
      setVendas([...vendas, ...newVendas]);
      setImportMessage(`\u2705 ${newVendas.length} vendas importadas com sucesso!`);
      setIsProcessing(false);
      setTimeout(() => setImportMessage(""), 3e3);
    } catch (error) {
      setImportMessage("\u274C Erro ao importar dados de vendas.");
      setIsProcessing(false);
      setTimeout(() => setImportMessage(""), 3e3);
    }
  };
  const importProventosData = (data) => {
    try {
      const requiredFields = ["tipo_provento", "ativo", "data", "valor"];
      const validData = data.filter(
        (item) => requiredFields.every((field) => item[field] && item[field] !== "")
      );
      if (validData.length === 0) {
        setImportMessage("\u274C Nenhum dado v\xE1lido encontrado no arquivo de proventos.");
        setIsProcessing(false);
        setTimeout(() => setImportMessage(""), 3e3);
        return;
      }
      const newProventos = validData.map((item) => ({
        id: Date.now() + Math.random(),
        tipo_provento: item.tipo_provento,
        ativo: item.ativo,
        data: item.data,
        valor: parseFloat(item.valor) || 0,
        quantidade: parseFloat(item.quantidade) || 0,
        a_receber: item.a_receber === "true",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }));
      setProventos([...proventos, ...newProventos]);
      setImportMessage(`\u2705 ${newProventos.length} proventos importados com sucesso!`);
      setIsProcessing(false);
      setTimeout(() => setImportMessage(""), 3e3);
    } catch (error) {
      setImportMessage("\u274C Erro ao importar dados de proventos.");
      setIsProcessing(false);
      setTimeout(() => setImportMessage(""), 3e3);
    }
  };
  const importDerivativosData = (data) => {
    try {
      const requiredFields = ["tipo_operacao", "tipo_derivativo", "ativo_subjacente", "codigo_opcao", "data", "quantidade", "preco"];
      const validData = data.filter(
        (item) => requiredFields.every((field) => item[field] && item[field] !== "")
      );
      if (validData.length === 0) {
        setImportMessage("\u274C Nenhum dado v\xE1lido encontrado no arquivo de derivativos.");
        setIsProcessing(false);
        setTimeout(() => setImportMessage(""), 3e3);
        return;
      }
      const newDerivativos = validData.map((item) => ({
        id: Date.now() + Math.random(),
        tipo_operacao: item.tipo_operacao,
        tipo_derivativo: item.tipo_derivativo,
        ativo_subjacente: item.ativo_subjacente,
        codigo_opcao: item.codigo_opcao,
        strike: parseFloat(item.strike) || 0,
        data: item.data,
        quantidade: parseFloat(item.quantidade) || 0,
        preco: parseFloat(item.preco) || 0,
        outros_custos: parseFloat(item.outros_custos) || 0,
        status: item.status || "aberta",
        valor_total: parseFloat(item.valor_total) || (parseFloat(item.quantidade) || 0) * (parseFloat(item.preco) || 0) + (parseFloat(item.outros_custos) || 0),
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }));
      setDerivativos([...derivativos, ...newDerivativos]);
      setImportMessage(`\u2705 ${newDerivativos.length} derivativos importados com sucesso!`);
      setIsProcessing(false);
      setTimeout(() => setImportMessage(""), 3e3);
    } catch (error) {
      setImportMessage("\u274C Erro ao importar dados de derivativos.");
      setIsProcessing(false);
      setTimeout(() => setImportMessage(""), 3e3);
    }
  };
  const limparTodosDados = () => {
    const confirmacao = window.confirm(
      "\u26A0\uFE0F ATEN\xC7\xC3O: Esta a\xE7\xE3o ir\xE1 apagar TODOS os dados salvos (compras, vendas, proventos, derivativos e valores atuais).\n\nEsta a\xE7\xE3o n\xE3o pode ser desfeita!\n\nTem certeza que deseja continuar?"
    );
    if (confirmacao) {
      const segundaConfirmacao = window.confirm(
        '\u{1F6A8} CONFIRMA\xC7\xC3O FINAL: Todos os seus dados ser\xE3o perdidos permanentemente!\n\nDigite "CONFIRMAR" se deseja realmente apagar tudo:'
      );
      if (segundaConfirmacao) {
        setCompras([]);
        setVendas([]);
        setProventos([]);
        setDerivativos([]);
        setValoresAtuais({});
        setImportMessage("\u2705 Todos os dados foram apagados com sucesso.");
        setTimeout(() => setImportMessage(""), 3e3);
      }
    }
  };
  const stats = getEstatisticas();
  const ativosUnicos = getAtivosUnicos();
  const dadosGraficos = getDadosGraficos();
  const proventosFiltrados = getProventosFiltrados();
  const proventosPorAtivo = getProventosPorAtivo();
  const derivativosPorAtivo = getDerivativosPorAtivo();
  return /* @__PURE__ */ React.createElement("div", { className: "min-h-screen bg-gray-900 text-white" }, /* @__PURE__ */ React.createElement("header", { className: "bg-gray-800 border-b border-gray-700 px-3 sm:px-6 py-3 sm:py-4" }, /* @__PURE__ */ React.createElement("div", { className: "max-w-7xl mx-auto" }, /* @__PURE__ */ React.createElement("div", { className: "hidden lg:flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(BarChart3, { className: "w-8 h-8 text-blue-400" }), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h1", { className: "text-2xl font-bold text-white" }, "Tekinform\xE1tica"), /* @__PURE__ */ React.createElement("p", { className: "text-sm text-gray-400" }, "Gerenciamento de Investimentos")))), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-4" }, /* @__PURE__ */ React.createElement("nav", { className: "flex space-x-1" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("dashboard"),
      className: `px-3 py-2 rounded-lg transition-colors ${activeTab === "dashboard" ? "bg-blue-600 text-white" : "text-gray-400 hover:text-white hover:bg-gray-700"}`
    },
    /* @__PURE__ */ React.createElement(Home, { className: "w-4 h-4 inline mr-2" }),
    "Dashboard"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("compra"),
      className: `px-3 py-2 rounded-lg transition-colors ${activeTab === "compra" ? "bg-green-600 text-white" : "text-gray-400 hover:text-white hover:bg-gray-700"}`
    },
    /* @__PURE__ */ React.createElement(TrendingUp, { className: "w-4 h-4 inline mr-2" }),
    "Comprar"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("venda"),
      className: `px-3 py-2 rounded-lg transition-colors ${activeTab === "venda" ? "bg-blue-600 text-white" : "text-gray-400 hover:text-white hover:bg-gray-700"}`
    },
    /* @__PURE__ */ React.createElement(TrendingDown, { className: "w-4 h-4 inline mr-2" }),
    "Vender"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("proventos"),
      className: `px-3 py-2 rounded-lg transition-colors ${activeTab === "proventos" ? "bg-purple-600 text-white" : "text-gray-400 hover:text-white hover:bg-gray-700"}`
    },
    /* @__PURE__ */ React.createElement(Gift, { className: "w-4 h-4 inline mr-2" }),
    "Proventos"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("derivativos"),
      className: `px-3 py-2 rounded-lg transition-colors ${activeTab === "derivativos" ? "bg-orange-600 text-white" : "text-gray-400 hover:text-white hover:bg-gray-700"}`
    },
    /* @__PURE__ */ React.createElement(Target, { className: "w-4 h-4 inline mr-2" }),
    "Derivativos"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("carteira"),
      className: `px-3 py-2 rounded-lg transition-colors ${activeTab === "carteira" ? "bg-indigo-600 text-white" : "text-gray-400 hover:text-white hover:bg-gray-700"}`
    },
    /* @__PURE__ */ React.createElement(PieChart, { className: "w-4 h-4 inline mr-2" }),
    "Carteira"
  )), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2 bg-gray-700 px-3 py-2 rounded-lg" }, /* @__PURE__ */ React.createElement(User, { className: "w-4 h-4 text-gray-400" }), /* @__PURE__ */ React.createElement("span", { className: "text-sm" }, "Admin")), /* @__PURE__ */ React.createElement(
    Settings,
    {
      className: "w-5 h-5 text-gray-400 cursor-pointer hover:text-white transition-colors",
      onClick: () => setActiveTab("configuracoes")
    }
  ))), /* @__PURE__ */ React.createElement("div", { className: "lg:hidden" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between mb-3" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(BarChart3, { className: "w-6 h-6 text-blue-400" }), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h1", { className: "text-lg font-bold text-white" }, "Tekinform\xE1tica"), /* @__PURE__ */ React.createElement("p", { className: "text-xs text-gray-400" }, "Gerenciamento de Investimentos"))), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1 bg-gray-700 px-2 py-1 rounded text-xs" }, /* @__PURE__ */ React.createElement(User, { className: "w-3 h-3 text-gray-400" }), /* @__PURE__ */ React.createElement("span", null, "Admin")), /* @__PURE__ */ React.createElement(
    Settings,
    {
      className: "w-5 h-5 text-gray-400 cursor-pointer hover:text-white transition-colors",
      onClick: () => setActiveTab("configuracoes")
    }
  ))), /* @__PURE__ */ React.createElement("div", { className: "overflow-x-auto scrollbar-hide" }, /* @__PURE__ */ React.createElement("nav", { className: "flex space-x-2 pb-2", style: { minWidth: "max-content" } }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("dashboard"),
      className: `flex items-center px-3 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === "dashboard" ? "bg-blue-600 text-white" : "text-gray-400 hover:text-white hover:bg-gray-700"}`
    },
    /* @__PURE__ */ React.createElement(Home, { className: "w-4 h-4 mr-1" }),
    /* @__PURE__ */ React.createElement("span", { className: "text-sm" }, "Dashboard")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("compra"),
      className: `flex items-center px-3 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === "compra" ? "bg-green-600 text-white" : "text-gray-400 hover:text-white hover:bg-gray-700"}`
    },
    /* @__PURE__ */ React.createElement(TrendingUp, { className: "w-4 h-4 mr-1" }),
    /* @__PURE__ */ React.createElement("span", { className: "text-sm" }, "Comprar")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("venda"),
      className: `flex items-center px-3 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === "venda" ? "bg-blue-600 text-white" : "text-gray-400 hover:text-white hover:bg-gray-700"}`
    },
    /* @__PURE__ */ React.createElement(TrendingDown, { className: "w-4 h-4 mr-1" }),
    /* @__PURE__ */ React.createElement("span", { className: "text-sm" }, "Vender")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("proventos"),
      className: `flex items-center px-3 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === "proventos" ? "bg-purple-600 text-white" : "text-gray-400 hover:text-white hover:bg-gray-700"}`
    },
    /* @__PURE__ */ React.createElement(Gift, { className: "w-4 h-4 mr-1" }),
    /* @__PURE__ */ React.createElement("span", { className: "text-sm" }, "Proventos")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("derivativos"),
      className: `flex items-center px-3 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === "derivativos" ? "bg-orange-600 text-white" : "text-gray-400 hover:text-white hover:bg-gray-700"}`
    },
    /* @__PURE__ */ React.createElement(Target, { className: "w-4 h-4 mr-1" }),
    /* @__PURE__ */ React.createElement("span", { className: "text-sm" }, "Derivativos")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("carteira"),
      className: `flex items-center px-3 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === "carteira" ? "bg-indigo-600 text-white" : "text-gray-400 hover:text-white hover:bg-gray-700"}`
    },
    /* @__PURE__ */ React.createElement(PieChart, { className: "w-4 h-4 mr-1" }),
    /* @__PURE__ */ React.createElement("span", { className: "text-sm" }, "Carteira")
  )))))), /* @__PURE__ */ React.createElement("div", { className: "max-w-7xl mx-auto px-3 sm:px-6 py-4 sm:py-6" }, activeTab === "dashboard" && /* @__PURE__ */ React.createElement("div", { className: "space-y-8" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-8 gap-3 sm:gap-4" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl p-4 sm:p-6 border border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 text-xs sm:text-sm" }, "Total Compras"), /* @__PURE__ */ React.createElement("p", { className: "text-lg sm:text-xl font-bold text-green-400" }, "R$ ", stats.totalCompras.toLocaleString("pt-BR", { minimumFractionDigits: 2 }))), /* @__PURE__ */ React.createElement(TrendingUp, { className: "w-5 h-5 sm:w-6 sm:h-6 text-green-400" }))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl p-4 sm:p-6 border border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 text-xs sm:text-sm" }, "Total Vendas"), /* @__PURE__ */ React.createElement("p", { className: "text-lg sm:text-xl font-bold text-blue-400" }, "R$ ", stats.totalVendas.toLocaleString("pt-BR", { minimumFractionDigits: 2 }))), /* @__PURE__ */ React.createElement(TrendingDown, { className: "w-5 h-5 sm:w-6 sm:h-6 text-blue-400" }))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl p-4 sm:p-6 border border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 text-xs sm:text-sm" }, "Valor Mercado Total"), /* @__PURE__ */ React.createElement("p", { className: "text-lg sm:text-xl font-bold text-cyan-400" }, "R$ ", stats.valorMercadoTotal.toLocaleString("pt-BR", { minimumFractionDigits: 2 }))), /* @__PURE__ */ React.createElement(PieChart, { className: "w-5 h-5 sm:w-6 sm:h-6 text-cyan-400" }))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl p-4 sm:p-6 border border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 text-xs sm:text-sm" }, "Saldo L\xEDquido"), /* @__PURE__ */ React.createElement("p", { className: `text-lg sm:text-xl font-bold ${stats.saldoLiquido >= 0 ? "text-green-400" : "text-red-400"}` }, stats.saldoLiquido >= 0 ? "+" : "", "R$ ", stats.saldoLiquido.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("p", { className: "text-xs text-gray-500 mt-1" }, "Valoriza\xE7\xE3o")), /* @__PURE__ */ React.createElement(DollarSign, { className: "w-5 h-5 sm:w-6 sm:h-6 text-yellow-400" }))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl p-4 sm:p-6 border border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 text-xs sm:text-sm" }, "Total Transa\xE7\xF5es"), /* @__PURE__ */ React.createElement("p", { className: "text-lg sm:text-xl font-bold text-purple-400" }, stats.totalTransacoes)), /* @__PURE__ */ React.createElement(Hash, { className: "w-5 h-5 sm:w-6 sm:h-6 text-purple-400" }))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl p-4 sm:p-6 border border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 text-xs sm:text-sm" }, "Proventos Recebidos"), /* @__PURE__ */ React.createElement("p", { className: "text-lg sm:text-xl font-bold text-emerald-400" }, "R$ ", stats.totalProventos.toLocaleString("pt-BR", { minimumFractionDigits: 2 }))), /* @__PURE__ */ React.createElement(Gift, { className: "w-5 h-5 sm:w-6 sm:h-6 text-emerald-400" }))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl p-4 sm:p-6 border border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 text-xs sm:text-sm" }, "A Receber"), /* @__PURE__ */ React.createElement("p", { className: "text-lg sm:text-xl font-bold text-orange-400" }, "R$ ", stats.proventosAReceber.toLocaleString("pt-BR", { minimumFractionDigits: 2 }))), /* @__PURE__ */ React.createElement(Receipt, { className: "w-5 h-5 sm:w-6 sm:h-6 text-orange-400" }))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl p-4 sm:p-6 border border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 text-xs sm:text-sm" }, "Derivativos Recebidos"), /* @__PURE__ */ React.createElement("p", { className: "text-lg sm:text-xl font-bold text-pink-400" }, "R$ ", stats.derivativosRecebidos.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("p", { className: "text-xs text-gray-500 mt-1" }, "Vendas de Call")), /* @__PURE__ */ React.createElement(Target, { className: "w-5 h-5 sm:w-6 sm:h-6 text-pink-400" })))), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 xl:grid-cols-2 gap-6 lg:gap-8" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl p-4 sm:p-6 border border-gray-700" }, /* @__PURE__ */ React.createElement("h3", { className: "text-base sm:text-lg font-semibold text-white mb-4 flex items-center" }, /* @__PURE__ */ React.createElement(PieChart, { className: "w-4 h-4 sm:w-5 sm:h-5 mr-2 text-emerald-400" }), "Distribui\xE7\xE3o de Proventos (12 meses)"), /* @__PURE__ */ React.createElement("div", { className: "min-h-80 sm:min-h-96 lg:min-h-[32rem] bg-gray-750 rounded-lg" }, dadosGraficos.proventosPorMes.some((item) => item.valor > 0) ? /* @__PURE__ */ React.createElement("div", { className: "w-full h-full flex flex-col lg:flex-row p-2 sm:p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex-1 flex items-center justify-center lg:justify-start lg:pl-4 mb-4 lg:mb-0" }, /* @__PURE__ */ React.createElement("div", { className: "relative" }, /* @__PURE__ */ React.createElement(
    "svg",
    {
      width: "100%",
      height: "100%",
      viewBox: "0 0 240 240",
      className: "transform -rotate-90 w-48 h-48 sm:w-56 sm:h-56 lg:w-60 lg:h-60"
    },
    (() => {
      const dadosComValor = dadosGraficos.proventosPorMes.filter((item) => item.valor > 0);
      const totalValor = dadosComValor.reduce((sum, item) => sum + item.valor, 0);
      if (totalValor === 0) return null;
      let cumulativePercentage = 0;
      const radius = 100;
      const centerX = 120;
      const centerY = 120;
      const cores = [
        "#10B981",
        "#3B82F6",
        "#8B5CF6",
        "#F59E0B",
        "#EF4444",
        "#06B6D4",
        "#84CC16",
        "#F97316",
        "#EC4899",
        "#6366F1",
        "#14B8A6",
        "#F43F5E"
      ];
      return dadosComValor.map((item, index) => {
        const percentage = item.valor / totalValor * 100;
        const angle = percentage / 100 * 360;
        const startAngle = cumulativePercentage / 100 * 360;
        const endAngle = startAngle + angle;
        const x1 = centerX + radius * Math.cos(startAngle * Math.PI / 180);
        const y1 = centerY + radius * Math.sin(startAngle * Math.PI / 180);
        const x2 = centerX + radius * Math.cos(endAngle * Math.PI / 180);
        const y2 = centerY + radius * Math.sin(endAngle * Math.PI / 180);
        const largeArcFlag = angle > 180 ? 1 : 0;
        const pathData = [
          `M ${centerX} ${centerY}`,
          `L ${x1} ${y1}`,
          `A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2}`,
          "Z"
        ].join(" ");
        cumulativePercentage += percentage;
        return /* @__PURE__ */ React.createElement("g", { key: index, className: "group cursor-pointer" }, /* @__PURE__ */ React.createElement(
          "path",
          {
            d: pathData,
            fill: cores[index % cores.length],
            className: "transition-all duration-300 hover:brightness-110",
            style: { transformOrigin: `${centerX}px ${centerY}px` }
          }
        ), /* @__PURE__ */ React.createElement("title", null, item.mesFormatado, ": R$ ", item.valor.toLocaleString("pt-BR", { minimumFractionDigits: 2 }), " (", percentage.toFixed(1), "%)"));
      });
    })()
  ), /* @__PURE__ */ React.createElement("div", { className: "absolute inset-0 flex items-center justify-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-center bg-gray-800 rounded-full w-16 h-16 sm:w-20 sm:h-20 flex flex-col items-center justify-center border-2 sm:border-4 border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-400 font-medium" }, "Total"), /* @__PURE__ */ React.createElement("div", { className: "text-xs sm:text-sm font-bold text-emerald-400" }, "R$ ", dadosGraficos.proventosPorMes.reduce((sum, item) => sum + item.valor, 0).toLocaleString("pt-BR", { minimumFractionDigits: 0, maximumFractionDigits: 0 })))))), /* @__PURE__ */ React.createElement("div", { className: "w-full lg:w-64 lg:ml-6 flex flex-col min-h-0" }, /* @__PURE__ */ React.createElement("h4", { className: "text-sm font-medium text-gray-300 mb-3 flex items-center" }, "\u{1F4C5} Meses com Proventos"), /* @__PURE__ */ React.createElement("div", { className: "flex-1 overflow-y-auto space-y-2 max-h-64 lg:max-h-80" }, (() => {
    const dadosComValor = dadosGraficos.proventosPorMes.filter((item) => item.valor > 0);
    const totalValor = dadosComValor.reduce((sum, item) => sum + item.valor, 0);
    const cores = [
      "#10B981",
      "#3B82F6",
      "#8B5CF6",
      "#F59E0B",
      "#EF4444",
      "#06B6D4",
      "#84CC16",
      "#F97316",
      "#EC4899",
      "#6366F1",
      "#14B8A6",
      "#F43F5E"
    ];
    return dadosComValor.sort((a, b) => b.valor - a.valor).map((item, index) => {
      const percentage = totalValor > 0 ? item.valor / totalValor * 100 : 0;
      const originalIndex = dadosComValor.findIndex((d) => d.mesFormatado === item.mesFormatado);
      return /* @__PURE__ */ React.createElement("div", { key: item.mesFormatado, className: "flex items-center justify-between group hover:bg-gray-700/50 rounded-lg p-2 sm:p-3 transition-colors cursor-pointer border border-gray-600/30" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2 sm:space-x-3" }, /* @__PURE__ */ React.createElement(
        "div",
        {
          className: "w-3 h-3 sm:w-4 sm:h-4 rounded-full flex-shrink-0 border border-gray-600",
          style: { backgroundColor: cores[originalIndex % cores.length] }
        }
      ), /* @__PURE__ */ React.createElement("div", { className: "flex flex-col" }, /* @__PURE__ */ React.createElement("span", { className: "text-xs sm:text-sm font-medium text-white" }, item.mesFormatado), /* @__PURE__ */ React.createElement("span", { className: "text-xs text-gray-400" }, percentage.toFixed(1), "% do total"))), /* @__PURE__ */ React.createElement("div", { className: "text-right" }, /* @__PURE__ */ React.createElement("div", { className: "text-xs sm:text-sm font-bold text-emerald-400" }, "R$ ", item.valor.toLocaleString("pt-BR", { minimumFractionDigits: 2 }))));
    });
  })()), /* @__PURE__ */ React.createElement("div", { className: "mt-4 pt-4 border-t border-gray-600 bg-gray-700/50 rounded-lg p-2 sm:p-3 flex-shrink-0" }, /* @__PURE__ */ React.createElement("h5", { className: "text-xs sm:text-sm font-medium text-gray-300 mb-2" }, "\u{1F4CA} Resumo"), /* @__PURE__ */ React.createElement("div", { className: "text-xs sm:text-sm text-gray-400 space-y-1 sm:space-y-2" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between" }, /* @__PURE__ */ React.createElement("span", null, "Meses ativos:"), /* @__PURE__ */ React.createElement("span", { className: "text-emerald-400 font-medium" }, dadosGraficos.proventosPorMes.filter((item) => item.valor > 0).length, " / 12")), /* @__PURE__ */ React.createElement("div", { className: "flex justify-between" }, /* @__PURE__ */ React.createElement("span", null, "M\xE9dia mensal:"), /* @__PURE__ */ React.createElement("span", { className: "text-emerald-400 font-medium" }, "R$ ", (dadosGraficos.proventosPorMes.reduce((sum, item) => sum + item.valor, 0) / 12).toLocaleString("pt-BR", { minimumFractionDigits: 2 }))), /* @__PURE__ */ React.createElement("div", { className: "flex justify-between" }, /* @__PURE__ */ React.createElement("span", null, "Melhor m\xEAs:"), /* @__PURE__ */ React.createElement("span", { className: "text-emerald-400 font-medium" }, (() => {
    const melhorMes = dadosGraficos.proventosPorMes.reduce(
      (max, item) => item.valor > max.valor ? item : max
    );
    return melhorMes.valor > 0 ? melhorMes.mesFormatado : "N/A";
  })())))))) : /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-center h-full" }, /* @__PURE__ */ React.createElement("div", { className: "text-center text-gray-400" }, /* @__PURE__ */ React.createElement(PieChart, { className: "w-12 h-12 mx-auto mb-4 opacity-50" }), /* @__PURE__ */ React.createElement("p", { className: "text-lg font-medium" }, "Nenhum provento recebido"), /* @__PURE__ */ React.createElement("p", { className: "text-sm mt-2" }, "Os proventos recebidos aparecer\xE3o neste gr\xE1fico quando forem lan\xE7ados"), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("proventos"),
      className: "mt-4 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 rounded-lg text-sm transition-colors"
    },
    "Lan\xE7ar Proventos \u2192"
  )))), dadosGraficos.proventosPorMes.some((item) => item.valor > 0) && /* @__PURE__ */ React.createElement("div", { className: "mt-4 pt-4 border-t border-gray-700 bg-gray-750 rounded-lg" }, /* @__PURE__ */ React.createElement("div", { className: "p-4" }, /* @__PURE__ */ React.createElement("h4", { className: "text-sm font-medium text-gray-300 mb-3" }, "\u{1F4CA} Estat\xEDsticas dos \xDAltimos 12 Meses"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-3 text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-400 mb-1" }, "Total Recebido"), /* @__PURE__ */ React.createElement("div", { className: "text-lg font-bold text-green-400" }, "R$ ", dadosGraficos.proventosPorMes.reduce((sum, item) => sum + item.valor, 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 }))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-3 text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-400 mb-1" }, "Melhor M\xEAs"), /* @__PURE__ */ React.createElement("div", { className: "text-sm font-bold text-green-400" }, (() => {
    const melhorMes = dadosGraficos.proventosPorMes.reduce(
      (max, item) => item.valor > max.valor ? item : max
    );
    return melhorMes.valor > 0 ? melhorMes.mesFormatado : "N/A";
  })()), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-green-300" }, "R$ ", Math.max(...dadosGraficos.proventosPorMes.map((i) => i.valor)).toLocaleString("pt-BR", { minimumFractionDigits: 2 }))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-3 text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-400 mb-1" }, "M\xE9dia Mensal"), /* @__PURE__ */ React.createElement("div", { className: "text-lg font-bold text-green-400" }, "R$ ", (dadosGraficos.proventosPorMes.reduce((sum, item) => sum + item.valor, 0) / 12).toLocaleString("pt-BR", { minimumFractionDigits: 2 }))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-3 text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-400 mb-1" }, "Meses com Proventos"), /* @__PURE__ */ React.createElement("div", { className: "text-lg font-bold text-green-400" }, dadosGraficos.proventosPorMes.filter((item) => item.valor > 0).length), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-green-300" }, "de 12 meses")))))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl p-4 sm:p-6 border border-gray-700" }, /* @__PURE__ */ React.createElement("h3", { className: "text-base sm:text-lg font-semibold text-white mb-4" }, "Distribui\xE7\xE3o de Ativos"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3" }, dadosGraficos.distribuicaoAtivos.length > 0 ? dadosGraficos.distribuicaoAtivos.map((item, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2 sm:space-x-3" }, /* @__PURE__ */ React.createElement(
    "div",
    {
      className: "w-3 h-3 sm:w-4 sm:h-4 rounded-full flex-shrink-0",
      style: { backgroundColor: `hsl(${index * 60}, 70%, 50%)` }
    }
  ), /* @__PURE__ */ React.createElement("span", { className: "text-sm font-medium text-white" }, item.ativo)), /* @__PURE__ */ React.createElement("div", { className: "text-right" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm font-semibold text-white" }, item.porcentagem, "%"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-400" }, "R$ ", item.valorInvestido.toLocaleString("pt-BR", { minimumFractionDigits: 0, maximumFractionDigits: 0 })), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-500" }, item.quantidade.toLocaleString("pt-BR", { maximumFractionDigits: 0 }), " cotas")))) : /* @__PURE__ */ React.createElement("div", { className: "text-center text-gray-400 py-8" }, /* @__PURE__ */ React.createElement(PieChart, { className: "w-12 h-12 mx-auto mb-4 opacity-50" }), /* @__PURE__ */ React.createElement("p", null, "Nenhum ativo cadastrado ainda"))))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-4 sm:p-6 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("h3", { className: "text-base sm:text-lg font-semibold text-white flex items-center" }, /* @__PURE__ */ React.createElement(BarChart3, { className: "w-4 h-4 sm:w-5 sm:h-5 mr-2 text-blue-400" }), "Hist\xF3rico de Ativos")), /* @__PURE__ */ React.createElement("div", { className: "overflow-x-auto" }, /* @__PURE__ */ React.createElement("table", { className: "w-full" }, /* @__PURE__ */ React.createElement("thead", { className: "bg-gray-700" }, /* @__PURE__ */ React.createElement("tr", null, /* @__PURE__ */ React.createElement("th", { className: "px-3 sm:px-6 py-2 sm:py-3 text-left text-xs sm:text-sm font-medium text-gray-300" }, "Data"), /* @__PURE__ */ React.createElement("th", { className: "px-3 sm:px-6 py-2 sm:py-3 text-left text-xs sm:text-sm font-medium text-gray-300 hidden sm:table-cell" }, "Tipo"), /* @__PURE__ */ React.createElement("th", { className: "px-3 sm:px-6 py-2 sm:py-3 text-left text-xs sm:text-sm font-medium text-gray-300" }, "Ativo"), /* @__PURE__ */ React.createElement("th", { className: "px-3 sm:px-6 py-2 sm:py-3 text-left text-xs sm:text-sm font-medium text-gray-300" }, "Op."), /* @__PURE__ */ React.createElement("th", { className: "px-3 sm:px-6 py-2 sm:py-3 text-left text-xs sm:text-sm font-medium text-gray-300 hidden md:table-cell" }, "Qtd"), /* @__PURE__ */ React.createElement("th", { className: "px-3 sm:px-6 py-2 sm:py-3 text-left text-xs sm:text-sm font-medium text-gray-300 hidden md:table-cell" }, "Pre\xE7o"), /* @__PURE__ */ React.createElement("th", { className: "px-3 sm:px-6 py-2 sm:py-3 text-left text-xs sm:text-sm font-medium text-gray-300" }, "Total"))), /* @__PURE__ */ React.createElement("tbody", { className: "divide-y divide-gray-700" }, [...compras.map((item) => ({ ...item, tipo_operacao: "compra" })), ...vendas.map((item) => ({ ...item, tipo_operacao: "venda" }))].sort((a, b) => new Date(b.data) - new Date(a.data)).slice(0, 10).map((item) => /* @__PURE__ */ React.createElement("tr", { key: `${item.tipo_operacao}-${item.id}`, className: "hover:bg-gray-700 transition-colors" }, /* @__PURE__ */ React.createElement("td", { className: "px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm text-gray-300" }, (/* @__PURE__ */ new Date(item.data + "T12:00:00")).toLocaleDateString("pt-BR")), /* @__PURE__ */ React.createElement("td", { className: "px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm text-gray-300 hidden sm:table-cell" }, /* @__PURE__ */ React.createElement("span", { className: "hidden lg:inline" }, tiposAtivos.find((t) => t.value === item.tipo_ativo)?.label || item.tipo_ativo), /* @__PURE__ */ React.createElement("span", { className: "lg:hidden" }, (tiposAtivos.find((t) => t.value === item.tipo_ativo)?.label || item.tipo_ativo).split(" ")[0])), /* @__PURE__ */ React.createElement("td", { className: "px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm text-white font-medium" }, item.ativo), /* @__PURE__ */ React.createElement("td", { className: "px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm" }, /* @__PURE__ */ React.createElement("span", { className: `px-2 py-1 rounded-full text-xs font-medium ${item.tipo_operacao === "compra" ? "bg-green-600 text-green-100" : "bg-blue-600 text-blue-100"}` }, /* @__PURE__ */ React.createElement("span", { className: "hidden sm:inline" }, item.tipo_operacao === "compra" ? "Compra" : "Venda"), /* @__PURE__ */ React.createElement("span", { className: "sm:hidden" }, item.tipo_operacao === "compra" ? "C" : "V"))), /* @__PURE__ */ React.createElement("td", { className: "px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm text-gray-300 hidden md:table-cell" }, item.quantidade), /* @__PURE__ */ React.createElement("td", { className: "px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm text-gray-300 hidden md:table-cell" }, "R$ ", item.preco.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm font-medium text-white" }, /* @__PURE__ */ React.createElement("div", { className: "md:hidden text-xs text-gray-400 mb-1" }, item.quantidade, " \xD7 R$ ", item.preco.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), "R$ ", item.valor_total.toLocaleString("pt-BR", { minimumFractionDigits: 2 })))))), [...compras, ...vendas].length === 0 && /* @__PURE__ */ React.createElement("div", { className: "p-8 text-center text-gray-400" }, /* @__PURE__ */ React.createElement(BarChart3, { className: "w-12 h-12 mx-auto mb-4 opacity-50" }), /* @__PURE__ */ React.createElement("p", null, "Nenhuma transa\xE7\xE3o com ativos registrada ainda."), /* @__PURE__ */ React.createElement("p", { className: "text-sm mt-2" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("compra"),
      className: "text-green-400 hover:text-green-300 transition-colors mr-2"
    },
    "Adicionar compra \u2192"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("venda"),
      className: "text-blue-400 hover:text-blue-300 transition-colors"
    },
    "Adicionar venda \u2192"
  ))), [...compras, ...vendas].length > 10 && /* @__PURE__ */ React.createElement("div", { className: "p-4 border-t border-gray-700 text-center" }, /* @__PURE__ */ React.createElement("p", { className: "text-sm text-gray-400" }, "Mostrando as 10 transa\xE7\xF5es mais recentes de ", [...compras, ...vendas].length, " total"), /* @__PURE__ */ React.createElement("div", { className: "mt-2 space-x-4" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("compra"),
      className: "text-sm text-green-400 hover:text-green-300 transition-colors"
    },
    "Ver todas as compras \u2192"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("venda"),
      className: "text-sm text-blue-400 hover:text-blue-300 transition-colors"
    },
    "Ver todas as vendas \u2192"
  ))))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-white flex items-center" }, /* @__PURE__ */ React.createElement(Gift, { className: "w-5 h-5 mr-2 text-emerald-400" }), "Proventos por Ativo")), /* @__PURE__ */ React.createElement("div", { className: "overflow-x-auto" }, /* @__PURE__ */ React.createElement("table", { className: "w-full" }, /* @__PURE__ */ React.createElement("thead", { className: "bg-gray-700" }, /* @__PURE__ */ React.createElement("tr", null, /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Ativo"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Total Recebido"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "A Receber"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Total Geral"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Opera\xE7\xF5es"))), /* @__PURE__ */ React.createElement("tbody", { className: "divide-y divide-gray-700" }, proventosPorAtivo.map((item, index) => /* @__PURE__ */ React.createElement("tr", { key: item.ativo, className: "hover:bg-gray-700 transition-colors" }, /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-white font-medium" }, item.ativo), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm font-medium text-green-400" }, "R$ ", item.totalRecebido.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm font-medium text-orange-400" }, "R$ ", item.totalAReceber.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm font-medium text-emerald-400" }, "R$ ", item.totalGeral.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm text-gray-300" }, /* @__PURE__ */ React.createElement("span", { className: "px-2 py-1 rounded-full text-xs font-medium bg-purple-600 text-purple-100" }, item.quantidadeOperacoes)))))), proventosPorAtivo.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "p-8 text-center text-gray-400" }, /* @__PURE__ */ React.createElement(Gift, { className: "w-12 h-12 mx-auto mb-4 opacity-50" }), /* @__PURE__ */ React.createElement("p", null, "Nenhum provento registrado ainda."), /* @__PURE__ */ React.createElement("p", { className: "text-sm mt-2" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("proventos"),
      className: "text-emerald-400 hover:text-emerald-300 transition-colors"
    },
    "Clique aqui para adicionar proventos \u2192"
  )))), proventosPorAtivo.length > 0 && /* @__PURE__ */ React.createElement("div", { className: "p-6 border-t border-gray-700 bg-gray-750" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Ativos com Proventos"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-emerald-400" }, proventosPorAtivo.length))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Maior Pagador"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-emerald-400" }, proventosPorAtivo.length > 0 ? proventosPorAtivo[0].ativo : "N/A"))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Maior Valor"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-emerald-400" }, "R$ ", proventosPorAtivo.length > 0 ? proventosPorAtivo[0].totalGeral.toLocaleString("pt-BR", { minimumFractionDigits: 2 }) : "0,00")))))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-white flex items-center" }, /* @__PURE__ */ React.createElement(Target, { className: "w-5 h-5 mr-2 text-orange-400" }), "Derivativos por Ativo Subjacente")), /* @__PURE__ */ React.createElement("div", { className: "overflow-x-auto" }, /* @__PURE__ */ React.createElement("table", { className: "w-full" }, /* @__PURE__ */ React.createElement("thead", { className: "bg-gray-700" }, /* @__PURE__ */ React.createElement("tr", null, /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Ativo Subjacente"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Total Compras"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Total Vendas"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Volume Total"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "CALLs"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "PUTs"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Opera\xE7\xF5es"))), /* @__PURE__ */ React.createElement("tbody", { className: "divide-y divide-gray-700" }, derivativosPorAtivo.map((item, index) => /* @__PURE__ */ React.createElement("tr", { key: item.ativo, className: "hover:bg-gray-700 transition-colors" }, /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-white font-medium" }, item.ativo), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm font-medium text-blue-400" }, "R$ ", item.totalCompras.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm font-medium text-purple-400" }, "R$ ", item.totalVendas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm font-medium text-orange-400" }, "R$ ", item.totalGeral.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-col text-xs" }, /* @__PURE__ */ React.createElement("span", { className: "text-blue-300" }, "C: R$ ", item.opcoes.calls.compras.toLocaleString("pt-BR", { minimumFractionDigits: 0 })), /* @__PURE__ */ React.createElement("span", { className: "text-purple-300" }, "V: R$ ", item.opcoes.calls.vendas.toLocaleString("pt-BR", { minimumFractionDigits: 0 })))), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-col text-xs" }, /* @__PURE__ */ React.createElement("span", { className: "text-blue-300" }, "C: R$ ", item.opcoes.puts.compras.toLocaleString("pt-BR", { minimumFractionDigits: 0 })), /* @__PURE__ */ React.createElement("span", { className: "text-purple-300" }, "V: R$ ", item.opcoes.puts.vendas.toLocaleString("pt-BR", { minimumFractionDigits: 0 })))), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, /* @__PURE__ */ React.createElement("span", { className: "px-2 py-1 rounded-full text-xs font-medium bg-orange-600 text-orange-100" }, item.quantidadeOperacoes)))))), derivativosPorAtivo.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "p-8 text-center text-gray-400" }, /* @__PURE__ */ React.createElement(Target, { className: "w-12 h-12 mx-auto mb-4 opacity-50" }), /* @__PURE__ */ React.createElement("p", null, "Nenhuma opera\xE7\xE3o com derivativos registrada ainda."), /* @__PURE__ */ React.createElement("p", { className: "text-sm mt-2" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("derivativos"),
      className: "text-orange-400 hover:text-orange-300 transition-colors"
    },
    "Clique aqui para adicionar derivativos \u2192"
  )))), derivativosPorAtivo.length > 0 && /* @__PURE__ */ React.createElement("div", { className: "p-6 border-t border-gray-700 bg-gray-750" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Ativos Operados"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-orange-400" }, derivativosPorAtivo.length))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Maior Volume"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-orange-400" }, derivativosPorAtivo.length > 0 ? derivativosPorAtivo[0].ativo : "N/A"))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Volume Total"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-orange-400" }, "R$ ", derivativosPorAtivo.reduce((sum, item) => sum + item.totalGeral, 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Total Opera\xE7\xF5es"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-orange-400" }, derivativosPorAtivo.reduce((sum, item) => sum + item.quantidadeOperacoes, 0)))))))), activeTab === "proventos" && /* @__PURE__ */ React.createElement("div", { className: "space-y-8" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-bold text-white flex items-center" }, /* @__PURE__ */ React.createElement(Gift, { className: "w-6 h-6 mr-2" }), editingProventoId ? "Editar Provento" : "Lan\xE7amento de Proventos"), editingProventoId && /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: handleCancelEditProvento,
      className: "px-4 py-2 bg-gray-600 hover:bg-gray-700 rounded-lg transition-colors flex items-center space-x-2"
    },
    /* @__PURE__ */ React.createElement(X, { className: "w-4 h-4" }),
    /* @__PURE__ */ React.createElement("span", null, "Cancelar")
  ))), /* @__PURE__ */ React.createElement("div", { className: "p-4 sm:p-6 lg:p-8" }, /* @__PURE__ */ React.createElement("form", { onSubmit: handleProventoSubmit, className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(Tag, { className: "w-4 h-4 inline mr-2" }), "Tipo de Provento *"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: proventoData.tipo_provento,
      onChange: (e) => setProventoData({ ...proventoData, tipo_provento: e.target.value }),
      className: `w-full px-3 sm:px-4 py-2 sm:py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors text-sm sm:text-base ${proventoErrors.tipo_provento ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-purple-500"}`
    },
    /* @__PURE__ */ React.createElement("option", { value: "" }, "Selecione o tipo de provento"),
    tiposProventos.map((tipo) => /* @__PURE__ */ React.createElement("option", { key: tipo.value, value: tipo.value }, tipo.label))
  ), proventoErrors.tipo_provento && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, proventoErrors.tipo_provento)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(BarChart3, { className: "w-4 h-4 inline mr-2" }), "Ativo *"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: proventoData.ativo,
      onChange: (e) => setProventoData({ ...proventoData, ativo: e.target.value }),
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${proventoErrors.ativo ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-purple-500"}`
    },
    /* @__PURE__ */ React.createElement("option", { value: "" }, "Selecione o ativo"),
    ativosUnicos.map((ativo) => /* @__PURE__ */ React.createElement("option", { key: ativo, value: ativo }, ativo))
  ), proventoErrors.ativo && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, proventoErrors.ativo)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(Calendar, { className: "w-4 h-4 inline mr-2" }), "Data do Recebimento *"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "date",
      value: proventoData.data,
      onChange: (e) => setProventoData({ ...proventoData, data: e.target.value }),
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${proventoErrors.data ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-purple-500"}`
    }
  ), proventoErrors.data && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, proventoErrors.data)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(DollarSign, { className: "w-4 h-4 inline mr-2" }), "Valor (R$) *"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      step: "0.01",
      min: "0",
      value: proventoData.valor,
      onChange: (e) => setProventoData({ ...proventoData, valor: e.target.value }),
      placeholder: "Ex: 50.00",
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${proventoErrors.valor ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-purple-500"}`
    }
  ), proventoErrors.valor && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, proventoErrors.valor)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(Hash, { className: "w-4 h-4 inline mr-2" }), "Quantidade de Cotas/A\xE7\xF5es"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      step: "0.01",
      min: "0",
      value: proventoData.quantidade,
      onChange: (e) => setProventoData({ ...proventoData, quantidade: e.target.value }),
      placeholder: "Ex: 100",
      className: "w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 transition-colors"
    }
  )), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-3" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "checkbox",
      id: "a_receber",
      checked: proventoData.a_receber,
      onChange: (e) => setProventoData({ ...proventoData, a_receber: e.target.checked }),
      className: "w-4 h-4 text-purple-600 bg-gray-700 border-gray-600 rounded focus:ring-purple-500"
    }
  ), /* @__PURE__ */ React.createElement("label", { htmlFor: "a_receber", className: "text-sm font-medium text-gray-300" }, /* @__PURE__ */ React.createElement(Receipt, { className: "w-4 h-4 inline mr-2" }), "Provento a receber"))), /* @__PURE__ */ React.createElement(
    "button",
    {
      type: "submit",
      disabled: isSubmitting,
      className: `w-full py-4 px-6 rounded-lg font-medium transition-all duration-200 flex items-center justify-center space-x-2 bg-purple-600 hover:bg-purple-700 focus:ring-purple-500 ${isSubmitting ? "opacity-50 cursor-not-allowed" : ""} focus:outline-none focus:ring-2`
    },
    isSubmitting ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "animate-spin rounded-full h-5 w-5 border-b-2 border-white" }), /* @__PURE__ */ React.createElement("span", null, "Processando...")) : /* @__PURE__ */ React.createElement(React.Fragment, null, editingProventoId ? /* @__PURE__ */ React.createElement(Save, { className: "w-5 h-5" }) : /* @__PURE__ */ React.createElement(PlusCircle, { className: "w-5 h-5" }), /* @__PURE__ */ React.createElement("span", null, editingProventoId ? "Salvar Altera\xE7\xF5es" : "Adicionar Provento"))
  )))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-bold text-white flex items-center" }, /* @__PURE__ */ React.createElement(Gift, { className: "w-6 h-6 mr-2 text-purple-400" }), "Hist\xF3rico de Opera\xE7\xF5es com Proventos"), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(Filter, { className: "w-4 h-4 text-gray-400" }), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: filters.tipo_provento,
      onChange: (e) => setFilters({ ...filters, tipo_provento: e.target.value }),
      className: "px-3 py-1 bg-gray-700 border border-gray-600 rounded text-sm"
    },
    /* @__PURE__ */ React.createElement("option", { value: "" }, "Todos os tipos"),
    tiposProventos.map((tipo) => /* @__PURE__ */ React.createElement("option", { key: tipo.value, value: tipo.value }, tipo.label))
  )), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: filters.ativo,
      onChange: (e) => setFilters({ ...filters, ativo: e.target.value }),
      className: "px-3 py-1 bg-gray-700 border border-gray-600 rounded text-sm"
    },
    /* @__PURE__ */ React.createElement("option", { value: "" }, "Todos os ativos"),
    ativosUnicos.map((ativo) => /* @__PURE__ */ React.createElement("option", { key: ativo, value: ativo }, ativo))
  ), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      value: filters.ano,
      onChange: (e) => setFilters({ ...filters, ano: parseInt(e.target.value) }),
      className: "px-3 py-1 bg-gray-700 border border-gray-600 rounded text-sm w-20",
      min: "2020",
      max: "2030"
    }
  )))), /* @__PURE__ */ React.createElement("div", { className: "overflow-x-auto" }, /* @__PURE__ */ React.createElement("table", { className: "w-full" }, /* @__PURE__ */ React.createElement("thead", { className: "bg-gray-700" }, /* @__PURE__ */ React.createElement("tr", null, /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Data"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Tipo"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Ativo"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Quantidade"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Valor"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Status"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "A\xE7\xF5es"))), /* @__PURE__ */ React.createElement("tbody", { className: "divide-y divide-gray-700" }, proventosFiltrados.map((provento) => /* @__PURE__ */ React.createElement("tr", { key: provento.id, className: "hover:bg-gray-700 transition-colors" }, /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, (/* @__PURE__ */ new Date(provento.data + "T12:00:00")).toLocaleDateString("pt-BR")), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm" }, /* @__PURE__ */ React.createElement("span", { className: "px-2 py-1 rounded-full text-xs font-medium bg-purple-600 text-purple-100" }, tiposProventos.find((t) => t.value === provento.tipo_provento)?.label || provento.tipo_provento)), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-white font-medium" }, provento.ativo), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, provento.quantidade || "-"), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm font-medium text-emerald-400" }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-col" }, /* @__PURE__ */ React.createElement("span", null, "R$ ", (provento.valor * (provento.quantidade || 1)).toLocaleString("pt-BR", { minimumFractionDigits: 2 })), provento.quantidade && provento.quantidade > 1 && /* @__PURE__ */ React.createElement("span", { className: "text-xs text-gray-400" }, "R$ ", provento.valor.toLocaleString("pt-BR", { minimumFractionDigits: 2 }), " \xD7 ", provento.quantidade))), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm" }, /* @__PURE__ */ React.createElement("span", { className: `px-2 py-1 rounded-full text-xs font-medium ${provento.a_receber ? "bg-orange-600 text-orange-100" : "bg-green-600 text-green-100"}` }, provento.a_receber ? "A Receber" : "Recebido")), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => handleEditProvento(provento),
      className: "p-2 text-blue-400 hover:text-blue-300 hover:bg-blue-900/20 rounded transition-colors",
      title: "Editar"
    },
    /* @__PURE__ */ React.createElement(Edit3, { className: "w-4 h-4" })
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => handleDeleteProvento(provento.id),
      className: "p-2 text-red-400 hover:text-red-300 hover:bg-red-900/20 rounded transition-colors",
      title: "Excluir"
    },
    /* @__PURE__ */ React.createElement(Trash2, { className: "w-4 h-4" })
  ))))))), proventosFiltrados.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "p-8 text-center text-gray-400" }, /* @__PURE__ */ React.createElement(Gift, { className: "w-12 h-12 mx-auto mb-4 opacity-50" }), /* @__PURE__ */ React.createElement("p", null, "Nenhum provento encontrado com os filtros aplicados."), /* @__PURE__ */ React.createElement("p", { className: "text-sm mt-2" }, "Adicione seu primeiro provento usando o formul\xE1rio acima."))), proventosFiltrados.length > 0 && /* @__PURE__ */ React.createElement("div", { className: "p-6 border-t border-gray-700 bg-gray-750" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Total Recebido"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-green-400" }, "R$ ", proventosFiltrados.filter((p) => !p.a_receber).reduce((sum, p) => sum + p.valor * (p.quantidade || 1), 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "A Receber"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-orange-400" }, "R$ ", proventosFiltrados.filter((p) => p.a_receber).reduce((sum, p) => sum + p.valor * (p.quantidade || 1), 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Total de Opera\xE7\xF5es"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-purple-400" }, proventosFiltrados.length))))))), activeTab === "derivativos" && /* @__PURE__ */ React.createElement("div", { className: "space-y-8" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-bold text-white flex items-center" }, /* @__PURE__ */ React.createElement(Target, { className: "w-6 h-6 mr-2 text-orange-400" }), editingDerivativoId ? "Editar Opera\xE7\xE3o" : "Derivativos - Op\xE7\xF5es de Compra e Venda"), editingDerivativoId && /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: handleCancelEditDerivativo,
      className: "px-4 py-2 bg-gray-600 hover:bg-gray-700 rounded-lg transition-colors flex items-center space-x-2"
    },
    /* @__PURE__ */ React.createElement(X, { className: "w-4 h-4" }),
    /* @__PURE__ */ React.createElement("span", null, "Cancelar")
  ))), /* @__PURE__ */ React.createElement("div", { className: "p-8" }, /* @__PURE__ */ React.createElement("form", { onSubmit: handleDerivativoSubmit, className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(Activity, { className: "w-4 h-4 inline mr-2" }), "Tipo de Opera\xE7\xE3o *"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: derivativoData.tipo_operacao,
      onChange: (e) => setDerivativoData({ ...derivativoData, tipo_operacao: e.target.value }),
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${derivativoErrors.tipo_operacao ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-orange-500"}`
    },
    /* @__PURE__ */ React.createElement("option", { value: "" }, "Selecione o tipo de opera\xE7\xE3o"),
    tiposOperacoes.map((tipo) => /* @__PURE__ */ React.createElement("option", { key: tipo.value, value: tipo.value }, tipo.label))
  ), derivativoErrors.tipo_operacao && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, derivativoErrors.tipo_operacao)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(Target, { className: "w-4 h-4 inline mr-2" }), "Tipo de Derivativo *"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: derivativoData.tipo_derivativo,
      onChange: (e) => setDerivativoData({ ...derivativoData, tipo_derivativo: e.target.value }),
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${derivativoErrors.tipo_derivativo ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-orange-500"}`
    },
    /* @__PURE__ */ React.createElement("option", { value: "" }, "Selecione o tipo de derivativo"),
    tiposDerivativo.map((tipo) => /* @__PURE__ */ React.createElement("option", { key: tipo.value, value: tipo.value }, tipo.label))
  ), derivativoErrors.tipo_derivativo && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, derivativoErrors.tipo_derivativo)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(BarChart3, { className: "w-4 h-4 inline mr-2" }), "Ativo Subjacente *"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: derivativoData.ativo_subjacente,
      onChange: (e) => setDerivativoData({ ...derivativoData, ativo_subjacente: e.target.value }),
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${derivativoErrors.ativo_subjacente ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-orange-500"}`
    },
    /* @__PURE__ */ React.createElement("option", { value: "" }, "Selecione o ativo subjacente"),
    ativosUnicos.map((ativo) => /* @__PURE__ */ React.createElement("option", { key: ativo, value: ativo }, ativo)),
    ativosPorTipo.acoes.map((ativo) => /* @__PURE__ */ React.createElement("option", { key: ativo, value: ativo }, ativo))
  ), derivativoErrors.ativo_subjacente && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, derivativoErrors.ativo_subjacente)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(Tag, { className: "w-4 h-4 inline mr-2" }), "C\xF3digo da Op\xE7\xE3o *"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: derivativoData.codigo_opcao,
      onChange: (e) => setDerivativoData({ ...derivativoData, codigo_opcao: e.target.value.toUpperCase() }),
      placeholder: "Ex: PETRA25",
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${derivativoErrors.codigo_opcao ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-orange-500"}`
    }
  ), derivativoErrors.codigo_opcao && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, derivativoErrors.codigo_opcao)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(DollarSign, { className: "w-4 h-4 inline mr-2" }), "Strike (Pre\xE7o de Exerc\xEDcio) *"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      step: "0.01",
      min: "0",
      value: derivativoData.strike,
      onChange: (e) => setDerivativoData({ ...derivativoData, strike: e.target.value }),
      placeholder: "Ex: 25.00",
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${derivativoErrors.strike ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-orange-500"}`
    }
  ), derivativoErrors.strike && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, derivativoErrors.strike)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(Calendar, { className: "w-4 h-4 inline mr-2" }), "Data da Opera\xE7\xE3o *"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "date",
      value: derivativoData.data,
      onChange: (e) => setDerivativoData({ ...derivativoData, data: e.target.value }),
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${derivativoErrors.data ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-orange-500"}`
    }
  ), derivativoErrors.data && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, derivativoErrors.data)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(Hash, { className: "w-4 h-4 inline mr-2" }), "Quantidade de Contratos *"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      step: "1",
      min: "1",
      value: derivativoData.quantidade,
      onChange: (e) => setDerivativoData({ ...derivativoData, quantidade: e.target.value }),
      placeholder: "Ex: 10",
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${derivativoErrors.quantidade ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-orange-500"}`
    }
  ), derivativoErrors.quantidade && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, derivativoErrors.quantidade)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(DollarSign, { className: "w-4 h-4 inline mr-2" }), "Pre\xE7o por Contrato (R$) *"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      step: "0.01",
      min: "0",
      value: derivativoData.preco,
      onChange: (e) => setDerivativoData({ ...derivativoData, preco: e.target.value }),
      placeholder: "Ex: 2.50",
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${derivativoErrors.preco ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-orange-500"}`
    }
  ), derivativoErrors.preco && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, derivativoErrors.preco)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center" }, /* @__PURE__ */ React.createElement(DollarSign, { className: "w-4 h-4 inline mr-2" }), "Outros Custos (R$)", /* @__PURE__ */ React.createElement("div", { className: "relative ml-2" }, /* @__PURE__ */ React.createElement(Info, { className: "w-4 h-4 text-gray-400 cursor-help" }), /* @__PURE__ */ React.createElement("div", { className: "absolute bottom-6 left-0 w-64 p-2 bg-gray-700 rounded-lg text-xs text-gray-300 opacity-0 hover:opacity-100 transition-opacity pointer-events-none" }, "Taxas de corretagem, impostos, emolumentos, etc.")))), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      step: "0.01",
      min: "0",
      value: derivativoData.outros_custos,
      onChange: (e) => setDerivativoData({ ...derivativoData, outros_custos: e.target.value }),
      placeholder: "Ex: 5.00",
      className: "w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 transition-colors"
    }
  )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(Info, { className: "w-4 h-4 inline mr-2" }), "Status da Op\xE7\xE3o"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: derivativoData.status,
      onChange: (e) => setDerivativoData({ ...derivativoData, status: e.target.value }),
      className: "w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 transition-colors"
    },
    statusOpcoes.map((status) => /* @__PURE__ */ React.createElement("option", { key: status.value, value: status.value }, status.label))
  ))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-6 border border-gray-600" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-lg font-medium text-gray-300" }, "Valor Total da Opera\xE7\xE3o:"), /* @__PURE__ */ React.createElement("span", { className: "text-2xl font-bold text-orange-400" }, "R$ ", calcularValorTotalDerivativo().toLocaleString("pt-BR", { minimumFractionDigits: 2 }))), derivativoData.quantidade && derivativoData.preco && /* @__PURE__ */ React.createElement("div", { className: "mt-2 text-sm text-gray-400" }, derivativoData.quantidade, " contratos \xD7 R$ ", parseFloat(derivativoData.preco).toLocaleString("pt-BR", { minimumFractionDigits: 2 }), derivativoData.outros_custos && parseFloat(derivativoData.outros_custos) > 0 && /* @__PURE__ */ React.createElement("span", null, " + R$ ", parseFloat(derivativoData.outros_custos).toLocaleString("pt-BR", { minimumFractionDigits: 2 }), " (outros custos)"))), /* @__PURE__ */ React.createElement(
    "button",
    {
      type: "submit",
      disabled: isSubmitting,
      className: `w-full py-4 px-6 rounded-lg font-medium transition-all duration-200 flex items-center justify-center space-x-2 bg-orange-600 hover:bg-orange-700 focus:ring-orange-500 ${isSubmitting ? "opacity-50 cursor-not-allowed" : ""} focus:outline-none focus:ring-2`
    },
    isSubmitting ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "animate-spin rounded-full h-5 w-5 border-b-2 border-white" }), /* @__PURE__ */ React.createElement("span", null, "Processando...")) : /* @__PURE__ */ React.createElement(React.Fragment, null, editingDerivativoId ? /* @__PURE__ */ React.createElement(Save, { className: "w-5 h-5" }) : /* @__PURE__ */ React.createElement(PlusCircle, { className: "w-5 h-5" }), /* @__PURE__ */ React.createElement("span", null, editingDerivativoId ? "Salvar Altera\xE7\xF5es" : "Adicionar Opera\xE7\xE3o"))
  )))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-bold text-white" }, "Hist\xF3rico de Opera\xE7\xF5es com Derivativos")), /* @__PURE__ */ React.createElement("div", { className: "overflow-x-auto" }, /* @__PURE__ */ React.createElement("table", { className: "w-full" }, /* @__PURE__ */ React.createElement("thead", { className: "bg-gray-700" }, /* @__PURE__ */ React.createElement("tr", null, /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Data"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Tipo"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Opera\xE7\xE3o"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Ativo Subjacente"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "C\xF3digo"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Strike"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Qtd"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Pre\xE7o"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Status"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Total"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "A\xE7\xF5es"))), /* @__PURE__ */ React.createElement("tbody", { className: "divide-y divide-gray-700" }, derivativos.map((derivativo) => /* @__PURE__ */ React.createElement("tr", { key: derivativo.id, className: "hover:bg-gray-700 transition-colors" }, /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, (/* @__PURE__ */ new Date(derivativo.data + "T12:00:00")).toLocaleDateString("pt-BR")), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm" }, /* @__PURE__ */ React.createElement("span", { className: `px-2 py-1 rounded-full text-xs font-medium ${derivativo.tipo_derivativo === "call" ? "bg-green-600 text-green-100" : "bg-red-600 text-red-100"}` }, derivativo.tipo_derivativo.toUpperCase())), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm" }, /* @__PURE__ */ React.createElement("span", { className: `px-2 py-1 rounded-full text-xs font-medium ${derivativo.tipo_operacao === "compra" ? "bg-blue-600 text-blue-100" : "bg-purple-600 text-purple-100"}` }, derivativo.tipo_operacao.charAt(0).toUpperCase() + derivativo.tipo_operacao.slice(1))), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-white font-medium" }, derivativo.ativo_subjacente), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, derivativo.codigo_opcao), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, /* @__PURE__ */ React.createElement("span", { className: "font-medium text-yellow-400" }, "R$ ", (derivativo.strike || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 }))), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, derivativo.quantidade), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, "R$ ", derivativo.preco.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm" }, /* @__PURE__ */ React.createElement("span", { className: `px-2 py-1 rounded-full text-xs font-medium ${derivativo.status === "aberta" ? "bg-yellow-600 text-yellow-100" : derivativo.status === "exercida" ? "bg-green-600 text-green-100" : "bg-gray-600 text-gray-100"}` }, statusOpcoes.find((s) => s.value === derivativo.status)?.label || derivativo.status)), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm font-medium text-white" }, "R$ ", derivativo.valor_total.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(
    "a",
    {
      href: `https://opcoes.net.br/${derivativo.codigo_opcao}`,
      target: "_blank",
      rel: "noopener noreferrer",
      className: "p-2 text-purple-400 hover:text-purple-300 hover:bg-purple-900/20 rounded transition-colors",
      title: `Ver ${derivativo.codigo_opcao} no Op\xE7\xF5es.net.br`
    },
    /* @__PURE__ */ React.createElement("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24" }, /* @__PURE__ */ React.createElement("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" }))
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => handleEditDerivativo(derivativo),
      className: "p-2 text-blue-400 hover:text-blue-300 hover:bg-blue-900/20 rounded transition-colors",
      title: "Editar"
    },
    /* @__PURE__ */ React.createElement(Edit3, { className: "w-4 h-4" })
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => handleDeleteDerivativo(derivativo.id),
      className: "p-2 text-red-400 hover:text-red-300 hover:bg-red-900/20 rounded transition-colors",
      title: "Excluir"
    },
    /* @__PURE__ */ React.createElement(Trash2, { className: "w-4 h-4" })
  ))))))), derivativos.length === 0 && /* @__PURE__ */ React.createElement("div", { className: "p-8 text-center text-gray-400" }, /* @__PURE__ */ React.createElement(Target, { className: "w-12 h-12 mx-auto mb-4 opacity-50" }), /* @__PURE__ */ React.createElement("p", null, "Nenhuma opera\xE7\xE3o com derivativos registrada ainda."), /* @__PURE__ */ React.createElement("p", { className: "text-sm mt-2" }, "Adicione sua primeira opera\xE7\xE3o usando o formul\xE1rio acima."))))), activeTab === "carteira" && /* @__PURE__ */ React.createElement("div", { className: "space-y-8" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-bold text-white flex items-center" }, /* @__PURE__ */ React.createElement(PieChart, { className: "w-6 h-6 mr-2 text-indigo-400" }), "Ativos (Carteira)"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 mt-2" }, "Vis\xE3o consolidada de todos os ativos com c\xE1lculo autom\xE1tico de lucros/preju\xEDzos")), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-4" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: updateStockPricesFromAPI,
      disabled: isUpdatingPrices,
      className: "px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 disabled:from-gray-600 disabled:to-gray-700 disabled:cursor-not-allowed text-white font-medium rounded-lg transition-all duration-300 transform hover:scale-105 flex items-center space-x-2 shadow-lg"
    },
    isUpdatingPrices ? /* @__PURE__ */ React.createElement("div", { className: "animate-spin rounded-full h-5 w-5 border-b-2 border-white" }) : /* @__PURE__ */ React.createElement(Activity, { className: "w-5 h-5" }),
    /* @__PURE__ */ React.createElement("span", null, isUpdatingPrices ? "Atualizando..." : "Atualizar Cota\xE7\xF5es")
  ), /* @__PURE__ */ React.createElement(
    "a",
    {
      href: "https://tekinf2025.github.io/brazilian_stock_tracker/pages/stock_market_dashboard.html",
      target: "_blank",
      rel: "noopener noreferrer",
      className: "px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium rounded-lg transition-all duration-300 transform hover:scale-105 flex items-center space-x-2 shadow-lg"
    },
    /* @__PURE__ */ React.createElement(BarChart3, { className: "w-5 h-5" }),
    /* @__PURE__ */ React.createElement("span", null, "Dashboard B3"),
    /* @__PURE__ */ React.createElement("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24" }, /* @__PURE__ */ React.createElement("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" }))
  )))), priceUpdateMessage && /* @__PURE__ */ React.createElement("div", { className: "p-4 bg-blue-900/20 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement("span", { className: "text-blue-400 font-medium" }, priceUpdateMessage))), /* @__PURE__ */ React.createElement("div", { className: "p-4 bg-gray-750 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between text-sm text-gray-400" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-4" }, /* @__PURE__ */ React.createElement("span", null, "\u{1F4E1} \xDAltima atualiza\xE7\xE3o: ", /* @__PURE__ */ React.createElement("strong", { className: "text-gray-300" }, formatLastUpdateTime())), /* @__PURE__ */ React.createElement("span", null, "|"), /* @__PURE__ */ React.createElement("span", null, "\u{1F3DB}\uFE0F Fonte: ", /* @__PURE__ */ React.createElement("strong", { className: "text-gray-300" }, "brapi.dev (B3)"))), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-4" }, /* @__PURE__ */ React.createElement("label", { className: "flex items-center space-x-2 cursor-pointer" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "checkbox",
      checked: autoUpdateEnabled,
      onChange: (e) => setAutoUpdateEnabled(e.target.checked),
      className: "w-4 h-4 text-green-600 bg-gray-700 border-gray-600 rounded focus:ring-green-500"
    }
  ), /* @__PURE__ */ React.createElement("span", { className: "text-gray-300" }, "Auto-atualizar na Carteira (5min)")), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement("div", { className: `w-2 h-2 rounded-full ${autoUpdateEnabled ? "bg-green-400" : "bg-gray-500"}` }), /* @__PURE__ */ React.createElement("span", null, "API ", autoUpdateEnabled ? "Ativa" : "Parada"))))), /* @__PURE__ */ React.createElement("div", { className: "p-6 bg-gray-750 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, "Buscar Ativo"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: carteiraFilters.busca,
      onChange: (e) => setCarteiraFilters({ ...carteiraFilters, busca: e.target.value }),
      placeholder: "Ex: PETR4, BBDC4...",
      className: "w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
    }
  )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, "Tipo de Ativo"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: carteiraFilters.tipo_ativo,
      onChange: (e) => setCarteiraFilters({ ...carteiraFilters, tipo_ativo: e.target.value }),
      className: "w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
    },
    /* @__PURE__ */ React.createElement("option", { value: "" }, "Todos os tipos"),
    tiposAtivos.map((tipo) => /* @__PURE__ */ React.createElement("option", { key: tipo.value, value: tipo.value }, tipo.label))
  )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, "Per\xEDodo"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: carteiraFilters.periodo,
      onChange: (e) => setCarteiraFilters({ ...carteiraFilters, periodo: e.target.value }),
      className: "w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
    },
    /* @__PURE__ */ React.createElement("option", { value: "" }, "Todos os per\xEDodos"),
    /* @__PURE__ */ React.createElement("option", { value: "30dias" }, "\xDAltimos 30 dias"),
    /* @__PURE__ */ React.createElement("option", { value: "6meses" }, "\xDAltimos 6 meses"),
    /* @__PURE__ */ React.createElement("option", { value: "ano" }, "Ano atual")
  )), /* @__PURE__ */ React.createElement("div", { className: "flex items-end" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setCarteiraFilters({ tipo_ativo: "", periodo: "", busca: "" }),
      className: "w-full px-3 sm:px-4 py-2 bg-gray-600 hover:bg-gray-700 rounded text-xs sm:text-sm transition-colors"
    },
    "Limpar Filtros"
  ))))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "overflow-x-auto" }, /* @__PURE__ */ React.createElement("table", { className: "w-full" }, /* @__PURE__ */ React.createElement("thead", { className: "bg-gray-700" }, /* @__PURE__ */ React.createElement("tr", null, /* @__PURE__ */ React.createElement(
    "th",
    {
      className: "px-3 sm:px-6 py-2 sm:py-3 text-left text-xs sm:text-sm font-medium text-gray-300 cursor-pointer hover:bg-gray-600 transition-colors",
      onClick: () => handleSort("ativo")
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1" }, /* @__PURE__ */ React.createElement("span", null, "Ativo"), getSortIcon("ativo"))
  ), /* @__PURE__ */ React.createElement(
    "th",
    {
      className: "px-6 py-3 text-left text-sm font-medium text-gray-300 cursor-pointer hover:bg-gray-600 transition-colors",
      onClick: () => handleSort("tipo_ativo")
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1" }, /* @__PURE__ */ React.createElement("span", null, "Tipo"), getSortIcon("tipo_ativo"))
  ), /* @__PURE__ */ React.createElement(
    "th",
    {
      className: "px-6 py-3 text-left text-sm font-medium text-gray-300 cursor-pointer hover:bg-gray-600 transition-colors",
      onClick: () => handleSort("quantidadeTotal")
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1" }, /* @__PURE__ */ React.createElement("span", null, "Qtd. Total"), getSortIcon("quantidadeTotal"))
  ), /* @__PURE__ */ React.createElement(
    "th",
    {
      className: "px-6 py-3 text-left text-sm font-medium text-gray-300 cursor-pointer hover:bg-gray-600 transition-colors",
      onClick: () => handleSort("precoMedio")
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1" }, /* @__PURE__ */ React.createElement("span", null, "Pre\xE7o M\xE9dio (R$)"), getSortIcon("precoMedio"))
  ), /* @__PURE__ */ React.createElement(
    "th",
    {
      className: "px-6 py-3 text-left text-sm font-medium text-gray-300 cursor-pointer hover:bg-gray-600 transition-colors",
      onClick: () => handleSort("valorAtual")
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1" }, /* @__PURE__ */ React.createElement("span", null, "Valor Atual (R$)"), getSortIcon("valorAtual"))
  ), /* @__PURE__ */ React.createElement(
    "th",
    {
      className: "px-6 py-3 text-left text-sm font-medium text-gray-300 cursor-pointer hover:bg-gray-600 transition-colors",
      onClick: () => handleSort("valorTotalCompras")
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1" }, /* @__PURE__ */ React.createElement("span", null, "Total Investido (R$)"), getSortIcon("valorTotalCompras"))
  ), /* @__PURE__ */ React.createElement(
    "th",
    {
      className: "px-6 py-3 text-left text-sm font-medium text-gray-300 cursor-pointer hover:bg-gray-600 transition-colors",
      onClick: () => handleSort("valorMercado")
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1" }, /* @__PURE__ */ React.createElement("span", null, "Valor Mercado (R$)"), getSortIcon("valorMercado"))
  ), /* @__PURE__ */ React.createElement(
    "th",
    {
      className: "px-6 py-3 text-left text-sm font-medium text-gray-300 cursor-pointer hover:bg-gray-600 transition-colors",
      onClick: () => handleSort("valorTotalVendas")
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1" }, /* @__PURE__ */ React.createElement("span", null, "Total Vendido (R$)"), getSortIcon("valorTotalVendas"))
  ), /* @__PURE__ */ React.createElement(
    "th",
    {
      className: "px-6 py-3 text-left text-sm font-medium text-gray-300 cursor-pointer hover:bg-gray-600 transition-colors",
      onClick: () => handleSort("lucroPrejuizo")
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1" }, /* @__PURE__ */ React.createElement("span", null, "Lucro / Preju\xEDzo (R$)"), getSortIcon("lucroPrejuizo"))
  ), /* @__PURE__ */ React.createElement(
    "th",
    {
      className: "px-6 py-3 text-left text-sm font-medium text-gray-300 cursor-pointer hover:bg-gray-600 transition-colors",
      onClick: () => handleSort("lucroPrejuizoLatente")
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1" }, /* @__PURE__ */ React.createElement("span", null, "Lucro/Preju\xEDzo Latente (R$)"), getSortIcon("lucroPrejuizoLatente"))
  ), /* @__PURE__ */ React.createElement(
    "th",
    {
      className: "px-6 py-3 text-left text-sm font-medium text-gray-300 cursor-pointer hover:bg-gray-600 transition-colors",
      onClick: () => handleSort("retornoPercentualLatente")
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1" }, /* @__PURE__ */ React.createElement("span", null, "% Valoriza\xE7\xE3o"), getSortIcon("retornoPercentualLatente"))
  ), /* @__PURE__ */ React.createElement(
    "th",
    {
      className: "px-6 py-3 text-left text-sm font-medium text-gray-300 cursor-pointer hover:bg-gray-600 transition-colors",
      onClick: () => handleSort("retornoPercentual")
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1" }, /* @__PURE__ */ React.createElement("span", null, "% Retorno Realizado"), getSortIcon("retornoPercentual"))
  ))), /* @__PURE__ */ React.createElement("tbody", { className: "divide-y divide-gray-700" }, getCarteiraData().map((item, index) => /* @__PURE__ */ React.createElement("tr", { key: `${item.ativo}-${index}`, className: "hover:bg-gray-700 transition-colors" }, /* @__PURE__ */ React.createElement("td", { className: "px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm text-white font-medium" }, item.ativo), /* @__PURE__ */ React.createElement("td", { className: "px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm text-gray-300" }, /* @__PURE__ */ React.createElement("span", { className: "px-2 py-1 rounded-full text-xs font-medium bg-blue-600 text-blue-100" }, /* @__PURE__ */ React.createElement("span", { className: "hidden md:inline" }, tiposAtivos.find((t) => t.value === item.tipo_ativo)?.label || item.tipo_ativo), /* @__PURE__ */ React.createElement("span", { className: "md:hidden" }, (tiposAtivos.find((t) => t.value === item.tipo_ativo)?.label || item.tipo_ativo).split(" ")[0]))), /* @__PURE__ */ React.createElement("td", { className: "px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm text-gray-300" }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-col" }, /* @__PURE__ */ React.createElement("span", { className: "font-medium" }, item.quantidadeTotal.toLocaleString("pt-BR", { maximumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("span", { className: "text-xs text-gray-400" }, "C: ", item.quantidadeComprada, " | V: ", item.quantidadeVendida))), /* @__PURE__ */ React.createElement("td", { className: "px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm text-gray-300" }, "R$ ", item.precoMedio.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, editingValorAtivo === item.ativo ? /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      step: "0.01",
      value: valorAtualTemp,
      onChange: (e) => setValorAtualTemp(e.target.value),
      className: "w-20 px-2 py-1 bg-gray-600 border border-gray-500 rounded text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500",
      autoFocus: true
    }
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => handleSaveValorAtual(item.ativo),
      className: "p-1 text-green-400 hover:text-green-300 transition-colors",
      title: "Salvar"
    },
    /* @__PURE__ */ React.createElement(Save, { className: "w-3 h-3" })
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: handleCancelEditValorAtual,
      className: "p-1 text-red-400 hover:text-red-300 transition-colors",
      title: "Cancelar"
    },
    /* @__PURE__ */ React.createElement(X, { className: "w-3 h-3" })
  )) : /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-col" }, /* @__PURE__ */ React.createElement("span", { className: item.valorAtual > 0 ? "text-white font-medium" : "text-gray-500" }, item.valorAtual > 0 ? `R$ ${item.valorAtual.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}` : "N\xE3o informado"), item.tipo_ativo === "acoes" && item.valorAtual > 0 && /* @__PURE__ */ React.createElement("span", { className: "text-xs text-emerald-400 flex items-center" }, /* @__PURE__ */ React.createElement("div", { className: "w-1 h-1 bg-emerald-400 rounded-full mr-1" }), "API B3")), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1" }, item.tipo_ativo === "acoes" && /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => updateSingleStockPrice(item.ativo),
      disabled: updatingSingleStock === item.ativo,
      className: "p-1 text-emerald-400 hover:text-emerald-300 disabled:text-gray-500 transition-colors",
      title: "Atualizar cota\xE7\xE3o via API"
    },
    updatingSingleStock === item.ativo ? /* @__PURE__ */ React.createElement("div", { className: "animate-spin rounded-full h-3 w-3 border border-emerald-400 border-t-transparent" }) : /* @__PURE__ */ React.createElement(Activity, { className: "w-3 h-3" })
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => handleEditValorAtual(item.ativo, item.valorAtual),
      className: "p-1 text-blue-400 hover:text-blue-300 transition-colors",
      title: "Editar valor manualmente"
    },
    /* @__PURE__ */ React.createElement(Edit3, { className: "w-3 h-3" })
  )))), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, "R$ ", item.valorTotalCompras.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-col" }, /* @__PURE__ */ React.createElement("span", { className: `font-medium ${item.valorMercado > 0 ? "text-white" : "text-gray-500"}` }, item.valorMercado > 0 ? `R$ ${item.valorMercado.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}` : "Valor n\xE3o definido"), item.quantidadeTotal > 0 && item.valorAtual > 0 && /* @__PURE__ */ React.createElement("span", { className: "text-xs text-gray-400" }, item.quantidadeTotal.toLocaleString("pt-BR", { maximumFractionDigits: 2 }), " \xD7 R$ ", item.valorAtual.toLocaleString("pt-BR", { minimumFractionDigits: 2 })))), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, "R$ ", item.valorTotalVendas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm font-medium" }, /* @__PURE__ */ React.createElement("span", { className: `${item.lucroPrejuizo >= 0 ? "text-green-400" : "text-red-400"}` }, item.lucroPrejuizo >= 0 ? "+" : "", "R$ ", item.lucroPrejuizo.toLocaleString("pt-BR", { minimumFractionDigits: 2 }))), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm font-medium" }, item.quantidadeTotal > 0 && item.valorAtual > 0 ? /* @__PURE__ */ React.createElement("span", { className: `${item.lucroPrejuizoLatente >= 0 ? "text-green-400" : "text-red-400"}` }, item.lucroPrejuizoLatente >= 0 ? "+" : "", "R$ ", item.lucroPrejuizoLatente.toLocaleString("pt-BR", { minimumFractionDigits: 2 })) : /* @__PURE__ */ React.createElement("span", { className: "text-gray-500" }, "-")), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm font-medium" }, item.quantidadeTotal > 0 && item.valorAtual > 0 ? /* @__PURE__ */ React.createElement("span", { className: `${item.retornoPercentualLatente >= 0 ? "text-green-400" : "text-red-400"}` }, item.retornoPercentualLatente >= 0 ? "+" : "", item.retornoPercentualLatente.toLocaleString("pt-BR", { minimumFractionDigits: 1 }), "%") : /* @__PURE__ */ React.createElement("span", { className: "text-gray-500" }, "-")), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm font-medium" }, /* @__PURE__ */ React.createElement("span", { className: `${item.retornoPercentual >= 0 ? "text-green-400" : "text-red-400"}` }, item.retornoPercentual >= 0 ? "+" : "", item.retornoPercentual.toLocaleString("pt-BR", { minimumFractionDigits: 1 }), "%")))))), getCarteiraData().length === 0 && /* @__PURE__ */ React.createElement("div", { className: "p-8 text-center text-gray-400" }, /* @__PURE__ */ React.createElement(PieChart, { className: "w-12 h-12 mx-auto mb-4 opacity-50" }), /* @__PURE__ */ React.createElement("p", null, "Nenhum ativo encontrado com os filtros aplicados."), /* @__PURE__ */ React.createElement("p", { className: "text-sm mt-2" }, "Realize algumas compras para ver os ativos em sua carteira."))), getCarteiraData().length > 0 && /* @__PURE__ */ React.createElement("div", { className: "p-6 border-t border-gray-700 bg-gray-750" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-white mb-4" }, "Resumo da Carteira"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Total Investido"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-blue-400" }, "R$ ", (() => {
    const totalCompras = getCarteiraData().reduce((sum, item) => sum + item.valorTotalCompras, 0);
    const totalVendas = getCarteiraData().reduce((sum, item) => sum + item.valorTotalVendas, 0);
    const totalProventos = proventos.filter((p) => !p.a_receber).reduce((sum, item) => sum + item.valor * (item.quantidade || 1), 0);
    const derivativosRecebidos = derivativos.filter((d) => d.tipo_operacao === "venda" && d.tipo_derivativo === "call").reduce((sum, item) => sum + item.valor_total, 0);
    return (totalCompras - totalVendas - totalProventos - derivativosRecebidos).toLocaleString("pt-BR", { minimumFractionDigits: 2 });
  })()))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Total Vendido"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-purple-400" }, "R$ ", getCarteiraData().reduce((sum, item) => sum + item.valorTotalVendas, 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Total Compra"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-green-400" }, "R$ ", getCarteiraData().reduce((sum, item) => sum + item.valorTotalCompras, 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Valor Mercado Total"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-cyan-400" }, "R$ ", getCarteiraData().filter((item) => item.quantidadeTotal > 0 && item.valorAtual > 0).reduce((sum, item) => sum + item.valorMercado, 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Lucro/Preju\xEDzo"), /* @__PURE__ */ React.createElement("span", { className: `text-lg font-bold ${(() => {
    const valorMercado = getCarteiraData().filter((item) => item.quantidadeTotal > 0 && item.valorAtual > 0).reduce((sum, item) => sum + item.valorMercado, 0);
    const totalCompras = getCarteiraData().reduce((sum, item) => sum + item.valorTotalCompras, 0);
    const totalVendas = getCarteiraData().reduce((sum, item) => sum + item.valorTotalVendas, 0);
    const totalProventos = proventos.filter((p) => !p.a_receber).reduce((sum, item) => sum + item.valor * (item.quantidade || 1), 0);
    const derivativosRecebidos = derivativos.filter((d) => d.tipo_operacao === "venda" && d.tipo_derivativo === "call").reduce((sum, item) => sum + item.valor_total, 0);
    const totalInvestido = totalCompras - totalVendas - totalProventos - derivativosRecebidos;
    return valorMercado - totalInvestido >= 0 ? "text-green-400" : "text-red-400";
  })()}` }, (() => {
    const valorMercado = getCarteiraData().filter((item) => item.quantidadeTotal > 0 && item.valorAtual > 0).reduce((sum, item) => sum + item.valorMercado, 0);
    const totalCompras = getCarteiraData().reduce((sum, item) => sum + item.valorTotalCompras, 0);
    const totalVendas = getCarteiraData().reduce((sum, item) => sum + item.valorTotalVendas, 0);
    const totalProventos = proventos.filter((p) => !p.a_receber).reduce((sum, item) => sum + item.valor * (item.quantidade || 1), 0);
    const derivativosRecebidos = derivativos.filter((d) => d.tipo_operacao === "venda" && d.tipo_derivativo === "call").reduce((sum, item) => sum + item.valor_total, 0);
    const totalInvestido = totalCompras - totalVendas - totalProventos - derivativosRecebidos;
    const lucroPrejuizo = valorMercado - totalInvestido;
    return (lucroPrejuizo >= 0 ? "+" : "") + "R$ " + lucroPrejuizo.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
  })()))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Ativos na Carteira"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-indigo-400" }, getCarteiraData().filter((item) => item.quantidadeTotal > 0).length))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-300" }, "Cota\xE7\xF5es Atualizadas"), /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-yellow-400" }, getCarteiraData().filter((item) => item.quantidadeTotal > 0 && item.valorAtual > 0).length, " / ", getCarteiraData().filter((item) => item.quantidadeTotal > 0).length))))))), (activeTab === "compra" || activeTab === "venda") && /* @__PURE__ */ React.createElement("div", { className: "space-y-8" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-bold text-white flex items-center" }, activeTab === "compra" ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(TrendingUp, { className: "w-6 h-6 mr-2 text-green-400" }), editingId ? "Editar Compra" : "Compra de Ativos") : /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(TrendingDown, { className: "w-6 h-6 mr-2 text-blue-400" }), editingId ? "Editar Venda" : "Venda de Ativos")), editingId && /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: handleCancelEdit,
      className: "px-4 py-2 bg-gray-600 hover:bg-gray-700 rounded-lg transition-colors flex items-center space-x-2"
    },
    /* @__PURE__ */ React.createElement(X, { className: "w-4 h-4" }),
    /* @__PURE__ */ React.createElement("span", null, "Cancelar")
  ))), /* @__PURE__ */ React.createElement("div", { className: "p-8" }, /* @__PURE__ */ React.createElement("form", { onSubmit: handleSubmit, className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(Tag, { className: "w-4 h-4 inline mr-2" }), "Tipo de Ativo *"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: formData.tipo_ativo,
      onChange: (e) => handleInputChange("tipo_ativo", e.target.value),
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${errors.tipo_ativo ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-blue-500"}`
    },
    /* @__PURE__ */ React.createElement("option", { value: "" }, "Selecione o tipo de ativo"),
    tiposAtivos.map((tipo) => /* @__PURE__ */ React.createElement("option", { key: tipo.value, value: tipo.value }, tipo.label))
  ), errors.tipo_ativo && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, errors.tipo_ativo)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(BarChart3, { className: "w-4 h-4 inline mr-2" }), "Ativo *"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: formData.ativo,
      onChange: (e) => handleInputChange("ativo", e.target.value),
      disabled: !formData.tipo_ativo,
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${errors.ativo ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-blue-500"} ${!formData.tipo_ativo ? "opacity-50 cursor-not-allowed" : ""}`
    },
    /* @__PURE__ */ React.createElement("option", { value: "" }, "Selecione o ativo"),
    formData.tipo_ativo && ativosPorTipo[formData.tipo_ativo]?.map((ativo) => /* @__PURE__ */ React.createElement("option", { key: ativo, value: ativo }, ativo))
  ), errors.ativo && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, errors.ativo)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(Calendar, { className: "w-4 h-4 inline mr-2" }), "Data da ", activeTab === "compra" ? "Compra" : "Venda", " *"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "date",
      value: formData.data,
      onChange: (e) => handleInputChange("data", e.target.value),
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${errors.data ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-blue-500"}`
    }
  ), errors.data && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, errors.data)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(Hash, { className: "w-4 h-4 inline mr-2" }), "Quantidade *"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      step: "0.01",
      min: "0",
      value: formData.quantidade,
      onChange: (e) => handleInputChange("quantidade", e.target.value),
      placeholder: "Ex: 100",
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${errors.quantidade ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-blue-500"}`
    }
  ), errors.quantidade && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, errors.quantidade)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement(DollarSign, { className: "w-4 h-4 inline mr-2" }), "Pre\xE7o por Unidade (R$) *"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      step: "0.01",
      min: "0",
      value: formData.preco,
      onChange: (e) => handleInputChange("preco", e.target.value),
      placeholder: "Ex: 30.50",
      className: `w-full px-4 py-3 bg-gray-700 border rounded-lg focus:outline-none focus:ring-2 transition-colors ${errors.preco ? "border-red-500 focus:ring-red-500" : "border-gray-600 focus:ring-blue-500"}`
    }
  ), errors.preco && /* @__PURE__ */ React.createElement("p", { className: "mt-1 text-sm text-red-400" }, errors.preco)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-300 mb-2" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center" }, /* @__PURE__ */ React.createElement(DollarSign, { className: "w-4 h-4 inline mr-2" }), "Outros Custos (R$)", /* @__PURE__ */ React.createElement("div", { className: "relative ml-2" }, /* @__PURE__ */ React.createElement(Info, { className: "w-4 h-4 text-gray-400 cursor-help" }), /* @__PURE__ */ React.createElement("div", { className: "absolute bottom-6 left-0 w-64 p-2 bg-gray-700 rounded-lg text-xs text-gray-300 opacity-0 hover:opacity-100 transition-opacity pointer-events-none" }, "Taxas de corretagem, impostos, emolumentos, etc.")))), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      step: "0.01",
      min: "0",
      value: formData.outros_custos,
      onChange: (e) => handleInputChange("outros_custos", e.target.value),
      placeholder: "Ex: 5.00",
      className: "w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
    }
  ))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-700 rounded-lg p-6 border border-gray-600" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "text-lg font-medium text-gray-300" }, "Valor Total da ", activeTab === "compra" ? "Compra" : "Venda", ":"), /* @__PURE__ */ React.createElement("span", { className: `text-2xl font-bold ${activeTab === "compra" ? "text-green-400" : "text-blue-400"}` }, "R$ ", calcularValorTotal().toLocaleString("pt-BR", { minimumFractionDigits: 2 }))), formData.quantidade && formData.preco && /* @__PURE__ */ React.createElement("div", { className: "mt-2 text-sm text-gray-400" }, formData.quantidade, " \xD7 R$ ", parseFloat(formData.preco).toLocaleString("pt-BR", { minimumFractionDigits: 2 }), formData.outros_custos && parseFloat(formData.outros_custos) > 0 && /* @__PURE__ */ React.createElement("span", null, " + R$ ", parseFloat(formData.outros_custos).toLocaleString("pt-BR", { minimumFractionDigits: 2 }), " (outros custos)"))), /* @__PURE__ */ React.createElement(
    "button",
    {
      type: "submit",
      disabled: isSubmitting,
      className: `w-full py-3 sm:py-4 px-4 sm:px-6 rounded-lg font-medium transition-all duration-200 flex items-center justify-center space-x-2 text-sm sm:text-base ${activeTab === "compra" ? "bg-green-600 hover:bg-green-700 focus:ring-green-500" : "bg-blue-600 hover:bg-blue-700 focus:ring-blue-500"} ${isSubmitting ? "opacity-50 cursor-not-allowed" : ""} focus:outline-none focus:ring-2`
    },
    isSubmitting ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "animate-spin rounded-full h-5 w-5 border-b-2 border-white" }), /* @__PURE__ */ React.createElement("span", null, "Processando...")) : /* @__PURE__ */ React.createElement(React.Fragment, null, editingId ? /* @__PURE__ */ React.createElement(Save, { className: "w-5 h-5" }) : /* @__PURE__ */ React.createElement(PlusCircle, { className: "w-5 h-5" }), /* @__PURE__ */ React.createElement("span", null, editingId ? "Salvar Altera\xE7\xF5es" : `Adicionar ${activeTab === "compra" ? "Compra" : "Venda"}`))
  )))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-bold text-white" }, "Hist\xF3rico de ", activeTab === "compra" ? "Compras" : "Vendas")), /* @__PURE__ */ React.createElement("div", { className: "overflow-x-auto" }, /* @__PURE__ */ React.createElement("table", { className: "w-full" }, /* @__PURE__ */ React.createElement("thead", { className: "bg-gray-700" }, /* @__PURE__ */ React.createElement("tr", null, /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Data"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Tipo"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Ativo"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Qtd"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Pre\xE7o Unit."), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Outros Custos"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "Total"), /* @__PURE__ */ React.createElement("th", { className: "px-6 py-3 text-left text-sm font-medium text-gray-300" }, "A\xE7\xF5es"))), /* @__PURE__ */ React.createElement("tbody", { className: "divide-y divide-gray-700" }, (activeTab === "compra" ? compras : vendas).map((item) => /* @__PURE__ */ React.createElement("tr", { key: item.id, className: "hover:bg-gray-700 transition-colors" }, /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, (/* @__PURE__ */ new Date(item.data + "T12:00:00")).toLocaleDateString("pt-BR")), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, tiposAtivos.find((t) => t.value === item.tipo_ativo)?.label || item.tipo_ativo), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-white font-medium" }, item.ativo), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, item.quantidade), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, "R$ ", item.preco.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm text-gray-300" }, "R$ ", item.outros_custos.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm font-medium text-white" }, "R$ ", item.valor_total.toLocaleString("pt-BR", { minimumFractionDigits: 2 })), /* @__PURE__ */ React.createElement("td", { className: "px-6 py-4 text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => handleEdit(item),
      className: "p-2 text-blue-400 hover:text-blue-300 hover:bg-blue-900/20 rounded transition-colors",
      title: "Editar"
    },
    /* @__PURE__ */ React.createElement(Edit3, { className: "w-4 h-4" })
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => handleDelete(item.id),
      className: "p-2 text-red-400 hover:text-red-300 hover:bg-red-900/20 rounded transition-colors",
      title: "Excluir"
    },
    /* @__PURE__ */ React.createElement(Trash2, { className: "w-4 h-4" })
  ))))))), (activeTab === "compra" ? compras : vendas).length === 0 && /* @__PURE__ */ React.createElement("div", { className: "p-8 text-center text-gray-400" }, /* @__PURE__ */ React.createElement(BarChart3, { className: "w-12 h-12 mx-auto mb-4 opacity-50" }), /* @__PURE__ */ React.createElement("p", null, "Nenhuma ", activeTab === "compra" ? "compra" : "venda", " registrada ainda."), /* @__PURE__ */ React.createElement("p", { className: "text-sm mt-2" }, "Adicione sua primeira transa\xE7\xE3o usando o formul\xE1rio acima."))))), activeTab === "configuracoes" && /* @__PURE__ */ React.createElement("div", { className: "space-y-8" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-bold text-white flex items-center" }, /* @__PURE__ */ React.createElement(Settings, { className: "w-6 h-6 mr-2 text-gray-400" }), "Configura\xE7\xF5es"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 mt-2" }, "Gerencie seus dados com conex\xE3o ao banco Supabase")), /* @__PURE__ */ React.createElement("div", { className: `p-6 border-b border-gray-700 ${connectionStatus === "connected" ? "bg-green-900/20" : connectionStatus === "error" ? "bg-red-900/20" : "bg-blue-900/20"}` }, /* @__PURE__ */ React.createElement("div", { className: "flex items-start space-x-3" }, connectionStatus === "connected" && /* @__PURE__ */ React.createElement(CheckCircle, { className: "w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" }), connectionStatus === "error" && /* @__PURE__ */ React.createElement(XCircle, { className: "w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" }), connectionStatus === "connecting" && /* @__PURE__ */ React.createElement("div", { className: "animate-spin rounded-full h-5 w-5 border-b-2 border-blue-400 mt-0.5 flex-shrink-0" }), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h3", { className: `font-medium mb-2 ${connectionStatus === "connected" ? "text-green-400" : connectionStatus === "error" ? "text-red-400" : "text-blue-400"}` }, connectionStatus === "connected" && "\u{1F7E2} Conectado ao Supabase", connectionStatus === "error" && "\u{1F534} Erro de Conex\xE3o", connectionStatus === "connecting" && "\u{1F7E1} Conectando..."), /* @__PURE__ */ React.createElement("p", { className: `text-sm ${connectionStatus === "connected" ? "text-green-200" : connectionStatus === "error" ? "text-red-200" : "text-blue-200"}` }, connectionStatus === "connected" && "Seus dados est\xE3o sendo sincronizados com o banco de dados em tempo real.", connectionStatus === "error" && "N\xE3o foi poss\xEDvel conectar ao banco de dados. Verifique a configura\xE7\xE3o.", connectionStatus === "connecting" && "Estabelecendo conex\xE3o com o banco de dados..."), connectionStatus === "error" && /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: loadDataFromSupabase,
      disabled: isLoading,
      className: "mt-3 px-4 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-lg transition-colors text-sm font-medium flex items-center space-x-2"
    },
    isLoading ? /* @__PURE__ */ React.createElement("div", { className: "animate-spin rounded-full h-4 w-4 border-b-2 border-white" }) : /* @__PURE__ */ React.createElement(Activity, { className: "w-4 h-4" }),
    /* @__PURE__ */ React.createElement("span", null, "Tentar Reconectar")
  ))))), (exportMessage || importMessage) && /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, exportMessage && exportMessage.includes("\u2705") && /* @__PURE__ */ React.createElement(CheckCircle, { className: "w-5 h-5 text-green-400" }), importMessage && importMessage.includes("\u2705") && /* @__PURE__ */ React.createElement(CheckCircle, { className: "w-5 h-5 text-green-400" }), exportMessage && exportMessage.includes("\u274C") || importMessage && importMessage.includes("\u274C") && /* @__PURE__ */ React.createElement(XCircle, { className: "w-5 h-5 text-red-400" }), /* @__PURE__ */ React.createElement("span", { className: `font-medium ${exportMessage && exportMessage.includes("\u2705") || importMessage && importMessage.includes("\u2705") ? "text-green-400" : "text-red-400"}` }, exportMessage || importMessage))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-white flex items-center" }, /* @__PURE__ */ React.createElement(Download, { className: "w-5 h-5 mr-2 text-green-400" }), "\u{1F4E4} Exportar Dados (.CSV)"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 mt-2" }, "Baixe seus dados como arquivos CSV para backup ou an\xE1lise externa")), /* @__PURE__ */ React.createElement("div", { className: "p-6" }, /* @__PURE__ */ React.createElement("div", { className: "mb-4 p-4 bg-blue-900/20 rounded-lg border border-blue-600" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-3" }, /* @__PURE__ */ React.createElement(Settings, { className: "w-5 h-5 text-blue-400" }), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", { className: "text-blue-400 font-medium" }, "Dados sincronizados com Supabase"), /* @__PURE__ */ React.createElement("p", { className: "text-blue-200 text-sm" }, "As exporta\xE7\xF5es refletem os dados atuais salvos no banco de dados.")))), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: testSupabaseConnection,
      disabled: isLoading,
      className: "p-4 rounded-lg border border-yellow-600 bg-yellow-900/20 hover:bg-yellow-800/30 text-yellow-400 hover:text-yellow-300 transition-all duration-200 flex flex-col items-center space-y-2"
    },
    isLoading ? /* @__PURE__ */ React.createElement("div", { className: "animate-spin rounded-full h-6 w-6 border-b-2 border-yellow-400" }) : /* @__PURE__ */ React.createElement(Shield, { className: "w-6 h-6" }),
    /* @__PURE__ */ React.createElement("span", { className: "font-medium" }, "Testar Conex\xE3o"),
    /* @__PURE__ */ React.createElement("span", { className: "text-xs opacity-75" }, "Verificar Supabase")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: loadDataFromSupabase,
      disabled: isLoading,
      className: "p-4 rounded-lg border border-blue-600 bg-blue-900/20 hover:bg-blue-800/30 text-blue-400 hover:text-blue-300 transition-all duration-200 flex flex-col items-center space-y-2"
    },
    isLoading ? /* @__PURE__ */ React.createElement("div", { className: "animate-spin rounded-full h-6 w-6 border-b-2 border-blue-400" }) : /* @__PURE__ */ React.createElement(Activity, { className: "w-6 h-6" }),
    /* @__PURE__ */ React.createElement("span", { className: "font-medium" }, "Recarregar Dados"),
    /* @__PURE__ */ React.createElement("span", { className: "text-xs opacity-75" }, "Sincronizar com BD")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: exportCompras,
      disabled: isProcessing || compras.length === 0,
      className: `p-4 rounded-lg border transition-all duration-200 flex flex-col items-center space-y-2 ${compras.length === 0 ? "border-gray-600 bg-gray-700/50 text-gray-500 cursor-not-allowed" : "border-green-600 bg-green-900/20 hover:bg-green-800/30 text-green-400 hover:text-green-300"}`
    },
    /* @__PURE__ */ React.createElement(TrendingUp, { className: "w-6 h-6" }),
    /* @__PURE__ */ React.createElement("span", { className: "font-medium" }, "Exportar Compras"),
    /* @__PURE__ */ React.createElement("span", { className: "text-xs opacity-75" }, compras.length, " registros")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: exportVendas,
      disabled: isProcessing || vendas.length === 0,
      className: `p-4 rounded-lg border transition-all duration-200 flex flex-col items-center space-y-2 ${vendas.length === 0 ? "border-gray-600 bg-gray-700/50 text-gray-500 cursor-not-allowed" : "border-blue-600 bg-blue-900/20 hover:bg-blue-800/30 text-blue-400 hover:text-blue-300"}`
    },
    /* @__PURE__ */ React.createElement(TrendingDown, { className: "w-6 h-6" }),
    /* @__PURE__ */ React.createElement("span", { className: "font-medium" }, "Exportar Vendas"),
    /* @__PURE__ */ React.createElement("span", { className: "text-xs opacity-75" }, vendas.length, " registros")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: exportProventos,
      disabled: isProcessing || proventos.length === 0,
      className: `p-4 rounded-lg border transition-all duration-200 flex flex-col items-center space-y-2 ${proventos.length === 0 ? "border-gray-600 bg-gray-700/50 text-gray-500 cursor-not-allowed" : "border-purple-600 bg-purple-900/20 hover:bg-purple-800/30 text-purple-400 hover:text-purple-300"}`
    },
    /* @__PURE__ */ React.createElement(Gift, { className: "w-6 h-6" }),
    /* @__PURE__ */ React.createElement("span", { className: "font-medium" }, "Exportar Proventos"),
    /* @__PURE__ */ React.createElement("span", { className: "text-xs opacity-75" }, proventos.length, " registros")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: exportDerivativos,
      disabled: isProcessing || derivativos.length === 0,
      className: `p-4 rounded-lg border transition-all duration-200 flex flex-col items-center space-y-2 ${derivativos.length === 0 ? "border-gray-600 bg-gray-700/50 text-gray-500 cursor-not-allowed" : "border-orange-600 bg-orange-900/20 hover:bg-orange-800/30 text-orange-400 hover:text-orange-300"}`
    },
    /* @__PURE__ */ React.createElement(Target, { className: "w-6 h-6" }),
    /* @__PURE__ */ React.createElement("span", { className: "font-medium" }, "Exportar Derivativos"),
    /* @__PURE__ */ React.createElement("span", { className: "text-xs opacity-75" }, derivativos.length, " registros")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: exportCarteiraConsolidada,
      disabled: isProcessing,
      className: "p-4 rounded-lg border border-indigo-600 bg-indigo-900/20 hover:bg-indigo-800/30 text-indigo-400 hover:text-indigo-300 transition-all duration-200 flex flex-col items-center space-y-2"
    },
    /* @__PURE__ */ React.createElement(PieChart, { className: "w-6 h-6" }),
    /* @__PURE__ */ React.createElement("span", { className: "font-medium" }, "Carteira Consolidada"),
    /* @__PURE__ */ React.createElement("span", { className: "text-xs opacity-75" }, "An\xE1lise completa")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: exportBackupCompleto,
      disabled: isProcessing,
      className: "p-4 rounded-lg border border-yellow-600 bg-yellow-900/20 hover:bg-yellow-800/30 text-yellow-400 hover:text-yellow-300 transition-all duration-200 flex flex-col items-center space-y-2"
    },
    /* @__PURE__ */ React.createElement(FileDown, { className: "w-6 h-6" }),
    /* @__PURE__ */ React.createElement("span", { className: "font-medium" }, "Backup Completo"),
    /* @__PURE__ */ React.createElement("span", { className: "text-xs opacity-75" }, "Todos os arquivos")
  )), isProcessing && /* @__PURE__ */ React.createElement("div", { className: "mt-4 p-4 bg-blue-900/20 rounded-lg border border-blue-600" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-3" }, /* @__PURE__ */ React.createElement("div", { className: "animate-spin rounded-full h-5 w-5 border-b-2 border-blue-400" }), /* @__PURE__ */ React.createElement("span", { className: "text-blue-400" }, "Processando exporta\xE7\xE3o..."))))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-white flex items-center" }, /* @__PURE__ */ React.createElement(Upload, { className: "w-5 h-5 mr-2 text-blue-400" }), "\u{1F4E5} Importar Dados (.CSV)"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 mt-2" }, "Recarregue dados salvos em outro navegador ou dispositivo")), /* @__PURE__ */ React.createElement("div", { className: "p-6" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4" }, /* @__PURE__ */ React.createElement("div", { className: "p-4 rounded-lg border border-gray-600 bg-gray-700/50" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-3 mb-3" }, /* @__PURE__ */ React.createElement(TrendingUp, { className: "w-5 h-5 text-green-400" }), /* @__PURE__ */ React.createElement("span", { className: "font-medium text-green-400" }, "Importar Compras")), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "file",
      accept: ".csv",
      onChange: (e) => handleFileImport(e, "compras"),
      disabled: isProcessing,
      className: "w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded text-sm text-gray-300 file:mr-3 file:py-1 file:px-3 file:rounded file:border-0 file:bg-green-600 file:text-white file:cursor-pointer hover:file:bg-green-700 disabled:opacity-50"
    }
  ), /* @__PURE__ */ React.createElement("p", { className: "text-xs text-gray-400 mt-2" }, "Formato: tipo_ativo,ativo,data,quantidade,preco,outros_custos")), /* @__PURE__ */ React.createElement("div", { className: "p-4 rounded-lg border border-gray-600 bg-gray-700/50" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-3 mb-3" }, /* @__PURE__ */ React.createElement(TrendingDown, { className: "w-5 h-5 text-blue-400" }), /* @__PURE__ */ React.createElement("span", { className: "font-medium text-blue-400" }, "Importar Vendas")), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "file",
      accept: ".csv",
      onChange: (e) => handleFileImport(e, "vendas"),
      disabled: isProcessing,
      className: "w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded text-sm text-gray-300 file:mr-3 file:py-1 file:px-3 file:rounded file:border-0 file:bg-blue-600 file:text-white file:cursor-pointer hover:file:bg-blue-700 disabled:opacity-50"
    }
  ), /* @__PURE__ */ React.createElement("p", { className: "text-xs text-gray-400 mt-2" }, "Formato: tipo_ativo,ativo,data,quantidade,preco,outros_custos")), /* @__PURE__ */ React.createElement("div", { className: "p-4 rounded-lg border border-gray-600 bg-gray-700/50" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-3 mb-3" }, /* @__PURE__ */ React.createElement(Gift, { className: "w-5 h-5 text-purple-400" }), /* @__PURE__ */ React.createElement("span", { className: "font-medium text-purple-400" }, "Importar Proventos")), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "file",
      accept: ".csv",
      onChange: (e) => handleFileImport(e, "proventos"),
      disabled: isProcessing,
      className: "w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded text-sm text-gray-300 file:mr-3 file:py-1 file:px-3 file:rounded file:border-0 file:bg-purple-600 file:text-white file:cursor-pointer hover:file:bg-purple-700 disabled:opacity-50"
    }
  ), /* @__PURE__ */ React.createElement("p", { className: "text-xs text-gray-400 mt-2" }, "Formato: tipo_provento,ativo,data,valor,quantidade,a_receber")), /* @__PURE__ */ React.createElement("div", { className: "p-4 rounded-lg border border-gray-600 bg-gray-700/50" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-3 mb-3" }, /* @__PURE__ */ React.createElement(Target, { className: "w-5 h-5 text-orange-400" }), /* @__PURE__ */ React.createElement("span", { className: "font-medium text-orange-400" }, "Importar Derivativos")), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "file",
      accept: ".csv",
      onChange: (e) => handleFileImport(e, "derivativos"),
      disabled: isProcessing,
      className: "w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded text-sm text-gray-300 file:mr-3 file:py-1 file:px-3 file:rounded file:border-0 file:bg-orange-600 file:text-white file:cursor-pointer hover:file:bg-orange-700 disabled:opacity-50"
    }
  ), /* @__PURE__ */ React.createElement("p", { className: "text-xs text-gray-400 mt-2" }, "Formato: tipo_operacao,tipo_derivativo,ativo_subjacente,codigo_opcao,strike,data..."))), isProcessing && /* @__PURE__ */ React.createElement("div", { className: "mt-4 p-4 bg-blue-900/20 rounded-lg border border-blue-600" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-3" }, /* @__PURE__ */ React.createElement("div", { className: "animate-spin rounded-full h-5 w-5 border-b-2 border-blue-400" }), /* @__PURE__ */ React.createElement("span", { className: "text-blue-400" }, "Processando importa\xE7\xE3o..."))))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-red-600 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b border-red-600" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-white flex items-center" }, /* @__PURE__ */ React.createElement(Shield, { className: "w-5 h-5 mr-2 text-red-400" }), "\u{1F5D1}\uFE0F Zona de Perigo"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 mt-2" }, "A\xE7\xF5es irrevers\xEDveis que podem resultar em perda de dados")), /* @__PURE__ */ React.createElement("div", { className: "p-6 bg-red-900/10" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "text-red-400 font-medium" }, "Limpar Todos os Dados"), /* @__PURE__ */ React.createElement("p", { className: "text-red-300 text-sm mt-1" }, "Remove permanentemente todos os dados salvos no navegador")), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: limparTodosDados,
      disabled: isProcessing,
      className: "px-4 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition-colors font-medium"
    },
    "\u{1F5D1}\uFE0F Limpar Tudo"
  )))), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 rounded-xl border border-gray-700 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b border-gray-700" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-white flex items-center" }, /* @__PURE__ */ React.createElement(Info, { className: "w-5 h-5 mr-2 text-gray-400" }), "\u2139\uFE0F Informa\xE7\xF5es T\xE9cnicas")), /* @__PURE__ */ React.createElement("div", { className: "p-6" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "text-white font-medium mb-2" }, "\u{1F4CA} Estat\xEDsticas dos Dados"), /* @__PURE__ */ React.createElement("div", { className: "space-y-2 text-sm text-gray-300" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between" }, /* @__PURE__ */ React.createElement("span", null, "Compras registradas:"), /* @__PURE__ */ React.createElement("span", { className: "text-green-400 font-medium" }, compras.length)), /* @__PURE__ */ React.createElement("div", { className: "flex justify-between" }, /* @__PURE__ */ React.createElement("span", null, "Vendas registradas:"), /* @__PURE__ */ React.createElement("span", { className: "text-blue-400 font-medium" }, vendas.length)), /* @__PURE__ */ React.createElement("div", { className: "flex justify-between" }, /* @__PURE__ */ React.createElement("span", null, "Proventos registrados:"), /* @__PURE__ */ React.createElement("span", { className: "text-purple-400 font-medium" }, proventos.length)), /* @__PURE__ */ React.createElement("div", { className: "flex justify-between" }, /* @__PURE__ */ React.createElement("span", null, "Derivativos registrados:"), /* @__PURE__ */ React.createElement("span", { className: "text-orange-400 font-medium" }, derivativos.length)), /* @__PURE__ */ React.createElement("div", { className: "flex justify-between" }, /* @__PURE__ */ React.createElement("span", null, "Cota\xE7\xF5es salvas:"), /* @__PURE__ */ React.createElement("span", { className: "text-cyan-400 font-medium" }, Object.keys(valoresAtuais).length)))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "text-white font-medium mb-2" }, "\u{1F527} Formato dos Arquivos CSV"), /* @__PURE__ */ React.createElement("div", { className: "space-y-2 text-sm text-gray-300" }, /* @__PURE__ */ React.createElement("p", null, "\u2022 ", /* @__PURE__ */ React.createElement("strong", null, "Compras/Vendas:"), " Dados de transa\xE7\xF5es com ativos"), /* @__PURE__ */ React.createElement("p", null, "\u2022 ", /* @__PURE__ */ React.createElement("strong", null, "Proventos:"), " Dividendos, JCP e rendimentos"), /* @__PURE__ */ React.createElement("p", null, "\u2022 ", /* @__PURE__ */ React.createElement("strong", null, "Derivativos:"), " Opera\xE7\xF5es com op\xE7\xF5es (calls/puts)"), /* @__PURE__ */ React.createElement("p", null, "\u2022 ", /* @__PURE__ */ React.createElement("strong", null, "Carteira:"), " An\xE1lise consolidada por ativo"), /* @__PURE__ */ React.createElement("p", { className: "text-amber-400 mt-3" }, "\u{1F4A1} ", /* @__PURE__ */ React.createElement("strong", null, "Dica:"), " Mantenha backups regulares dos seus dados")))))))));
};
var stdin_default = InvestmentManager;
export {
  stdin_default as default
};
